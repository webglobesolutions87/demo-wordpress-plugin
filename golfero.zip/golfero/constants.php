<?php
// Prevent direct access to the script
if (!defined('WPINC')) die;

// Set plugin version
define('GLF_PLUGIN_VERSION', '1.0.0');
// Set template directory golfero/templates
define('GLF_TEMPLATES_DIR', plugin_dir_path(__FILE__) . 'templates/');