<div class="wrap">
<h1><?= $title ?></h1>

<form method="post" action="options.php">
    <?php settings_fields( 'glofero-settings-group' ); ?>
    <?php do_settings_sections( 'glofero-settings-group' ); ?>
    <table class="form-table">
        <tr valign="top">            
            <td>
                <div><strong><?= $lang['pending_posts_title'][ICL_LANGUAGE_CODE] ?></strong></div>
                <div style="margin:15px 0 0 0;">
                    <?php $content = get_option('pending_posts_'.ICL_LANGUAGE_CODE); ?>
                    <?php wp_editor( $content, 'pending_posts_'.ICL_LANGUAGE_CODE, $settings = [
                        'wpautop' => true, // use wpautop?
                        'media_buttons' => true, // show insert/upload button(s)
                        'textarea_name' => 'pending_posts_'.ICL_LANGUAGE_CODE, // set the textarea name to something different, square brackets [] can be used here                
                        'buttons' => 'strong,em,link,block,del,ins,img,ul,ol,li,code,more',
                        'quicktags' => true
                    ] ); ?>
                </div>
            </td>
        </tr>
        <tr valign="top">            
            <td>
                <div><strong><?= $lang['published_posts_title'][ICL_LANGUAGE_CODE] ?></strong></div>
                <div style="margin:15px 0 0 0;">
                    <?php $content =  get_option('published_posts_'.ICL_LANGUAGE_CODE); ?>
                    <?php wp_editor( $content, 'published_posts_'.ICL_LANGUAGE_CODE, $settings = [
                        'wpautop' => true, // use wpautop?
                        'media_buttons' => true, // show insert/upload button(s)
                        'textarea_name' => 'published_posts_'.ICL_LANGUAGE_CODE, // set the textarea name to something different, square brackets [] can be used here                
                        'buttons' => 'strong,em,link,block,del,ins,img,ul,ol,li,code,more',
                        'quicktags' => true
                    ] ); ?>
                </div>
            </td>
        </tr>
    </table>
    
    <?php submit_button(); ?>
    <div><?= $lang['general_instruction_about_language'][ICL_LANGUAGE_CODE] ?></div>

</form>
</div>