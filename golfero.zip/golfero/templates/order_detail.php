<div class="mg_pad_left_right_30">
    <div class="mg_container" style="width:100%;">
        <div class="mg_w_70 mg_pad_right_3" style="width:100%;">
            <article class="pluto-page-box">
                <div class="mg_pad_left_right_top_bottom_30">
                    <div class="post-content" style="font-size:12px;line-height:14px;">
                        <h1 class="page-title" style="font-size:20px;margin:3px 0 30px 0;padding:8px 0;">ORDER DETAIL</h1>
                        <?php if(!$error): ?>
                        <table width="100%" cellpadding="0" cellspacing="0">
                        <tr>
                            <td width="34%" valign="top">
                                <h4>General</h4>
                                <div>
                                    <div><strong>Order ID</strong></div>
                                    <div><?= $order_id ?></div>
                                </div>
                                <div style="margin:8px 0 0 0;">
                                    <div><strong>Order Created on</strong></div>
                                    <div><?= $order_created_on ?></div>
                                </div>
                                <div style="margin:8px 0 0 0;">
                                    <div><strong>Order Created on</strong></div>
                                    <div><?= $order_created_on ?></div>
                                </div>
                                <div style="margin:8px 0 0 0;">
                                    <div><strong>Order Status</strong></div>
                                    <div><?= $order_status ?></div>
                                </div>
                            </td>
                            <td width="33%" valign="top">
                                <h4>Billing</h4>
                                <div>
                                    <div><?= $order_detail['billing']['company'] ?></div>
                                    <div><?= $order_detail['billing']['first_name'].' '.$order_detail['billing']['last_name'] ?></div>
                                    <div><?= $order_detail['billing']['address_1'] ?></div>
                                    <div><?= $order_detail['billing']['address_2'] ?></div>
                                    <div><?= $order_detail['billing']['city'].', '.$order_detail['billing']['postcode'] ?></div>
                                    <div><?= $order_detail['billing']['state'].', '.$order_detail['billing']['country'] ?></div>
                                </div>
                                <div style="margin:8px 0 0 0;">
                                    <div><strong>Email</strong></div>
                                    <div><?= $order_detail['billing']['email'] ?></div>
                                </div>
                                <div style="margin:8px 0 0 0;">
                                    <div><strong>Phone</strong></div>
                                    <div><?= $order_detail['billing']['phone'] ?></div>
                                </div>
                            </td>
                            <td width="33%" valign="top">
                                <h4>Shipping</h4>
                                <div>
                                    <div><strong>Address:</strong></div>
                                    <div>No shipping address set.</div>
                                </div>
                            </td>
                        </tr>
                        <tr><td colspan="3">&nbsp;</td></tr>
                        <tr><td colspan="3" style="border-top:1px solid #ccc;">&nbsp;</td></tr>
                        <tr>
                            <td colspan="3">
                                <table width="100%" cellpadding="0" cellspacing="0" border="0">
                                <tr>
                                    <th width="55%" align="left">Item</th>
                                    <th width="15%" align="center">Cost</th>
                                    <th width="15%" align="center">Quantity</th>
                                    <th width="15%" align="center">Total</th>
                                </tr>
                                <tr><td colspan="4" style="padding:0 0 5px 0;border-bottom:1px soild #ccc;"></td></tr>
                                <?php if((isset($order_items)) && (is_array($order_items)) && (count($order_items))): ?>
                                <?php foreach($order_items as $k => $v): ?>
                                <?php
                                    $product = $v->get_product();
                                ?>
                                <tr>
                                    <td align="left"><?= $product->get_name() ?></td>
                                    <td align="center"><?= wc_price($product->get_price()) ?></td>
                                    <td align="center"><?= $v->get_quantity() ?></td>
                                    <td align="center"><?= wc_price($product->get_price()*$v->get_quantity()) ?></td>
                                </tr>
                                <?php endforeach; ?>
                                <tr><td colspan="4">&nbsp;</td></tr>
                                <tr><td colspan="4" style="border-top:1px solid #ccc;">&nbsp;</td></tr>
                                <tr><td colspan="4">&nbsp;</td></tr>
                                <tr>
                                    <td colspan="2">Payment via <?= $payment_method ?>. Customer IP : <?= $customer_ip ?></td>
                                    <td align="center">Total:</td>
                                    <td align="center"><?= wc_price($order_total) ?></td>
                                </tr>
                                <?php else: ?>
                                <tr><td colspan="4" class="error">No item found!</td></tr>
                                <?php endif; ?>
                                </table>
                            </td>
                            <tr><td>&nbsp;</td></tr>
                            <tr>
                                <td>
                                    <a class="btn submit-button preview-btn" href="<?= get_site_url().'/'.ICL_LANGUAGE_CODE.'/orders' ?>">&laquo; All Orders</a>
                                </td>
                            </tr>
                        </tr>                        
                        </table>
                        <?php else: ?>
                        <div class="error">Error! You are not authorized to access this URL.</div>
                        <?php endif; ?>
                    </div>
                </div>
            </article>
        </div>
    </div>
</div>