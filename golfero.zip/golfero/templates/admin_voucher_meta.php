<div>
    <div><strong>Voucher code used</strong></div>
    <div><?= (is_object($voucher)) ? $voucher->voucher_code : '-' ; ?></div>
    
    <?php if($order_status <> ''): ?>
    <div style="margin:10px 0 0 0;"><strong>Order Status</strong></div>
    <div><a target="_blank" href="<?= admin_url('post.php?post='.$order_id.'&action=edit') ?>"><?= ($order_status <> '') ? $order_status : '-' ; ?></a></div>
    <?php endif; ?>
</div>