<div class="mg_pad_left_right_30">
    <div class="mg_container" style="width:100%;">
        <div class="mg_w_70 mg_pad_right_3">
            <article class="pluto-page-box">
                <div class="mg_pad_left_right_top_bottom_30">
                    <div class="post-content">
                        <h1 class="page-title" style="font-size:20px;margin:3px 0 7px 0;padding:8px 0;"><?= strtoupper($title) ?></h1>
                        <?php if((isset($_GET['updated'])) && ($_GET['updated'] <> '')): ?>
                            <div class="success">Profile Information has been updated successfully.</div>
                            <div style="margin:10px 0;"></div>
                        <?php endif; ?>
                        <form action="<?= admin_url('admin-post.php'); ?>" method="post" id="frmEditProfile">
                        <input type="hidden" name="action" value="save_profile_info" />
                        <div>
                            <div>Profile Name</div>
                            <div><input name="user_nicename" id="user_nicename" value="<?= $user->data->user_nicename ?>" style="width:50%;"/></div>
                        </div>
                        <div style="margin:15px 0 0 0;">
                            <div>First Name</div>
                            <div><input name="first_name" id="first_name" value="<?= $first_name ?>" style="width:50%;"/></div>
                        </div>
                        <div style="margin:15px 0 0 0;">
                            <div>Last Name</div>
                            <div><input name="last_name" id="last_name" value="<?= $last_name ?>" style="width:50%;"/></div>
                        </div>
                        <div style="margin:15px 0 0 0;">
                            <div>Email</div>
                            <div><input name="user_email" id="user_email" disabled value="<?= $user->data->user_email ?>" style="width:50%;"/></div>
                            <div style="font-size:13px;"><strong>Note</strong> The email id can not be altered.</div>
                        </div>
                        <div style="margin:15px 0 0 0;">
                            <div>Gender</div>
                            <div>
                                <select name="gender" id="gender" class="select-holder" style="width:30%;border-radius:0px!important;padding:3px 7px;">
                                    <option value=""> -- SELECT GENDER -- </option>
                                    <option value="Male" <?= (strtolower($gender) == 'male') ? 'selected' : '' ; ?>>Male</option>
                                    <option value="Female" <?= (strtolower($gender) == 'female') ? 'selected' : '' ; ?>>Female</option>
                                </select>
                            </div>
                        </div>
                        <div style="margin:15px 0 0 0;">
                            <div>Profile Image</div>
                            <div>
                                <label for="file-upload" class="custom-file-upload" id="custom-file-upload"><i class="fa fa-picture-o" aria-hidden="true"></i><span class="border-line d-border-line">Set Profile Image</span></label>
                                <!-- <input id="file-upload" name='upload' accept="image/*" type="file" style="display:none;"> -->
                                <input type="hidden" id="file-upload" name="profilepicture" value=""/>
                            </div>
                            <div id="profile_image">
                                <img src="<?= $profilepicture ?>" alt="" title="" style="max-width:150px;">
                                <input type="hidden" id="hide_profile_picture" value="<?= $_profilepicture ?>" />
                            </div>
                        </div>
                        <div style="margin:15px 0 0 0;">
                            <button type="submit" name="btnEditProfile" class="btn">Save Profile Details</button>
                            <a href="<?= home_url(ICL_LANGUAGE_CODE.'/dashboard'); ?>" class="btn preview-btn">Cancel &amp; Return</a>
                        </div>
                        </form>
                    </div>
                </div>
            </article>
        </div>        
    </div>
</div>
<input type="hidden" id="home_url" value="<?= home_url() ?>" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script>
    $(document).ready(function() {       

        jQuery(document).ready(function($){
            var _custom_media = false,
            _orig_send_attachment = wp.media.editor.send.attachment;

            $('#custom-file-upload').click(function(e) {
                var send_attachment_bkp = wp.media.editor.send.attachment;
                var button = $(this);
                // var id = button.attr('id').replace('_button', '');
                var id = 'file-upload';
                _custom_media = false;
                wp.media.editor.send.attachment = function(props, attachment){
                    if ( _custom_media ) {
                        $("#"+id).val(attachment.url);
                    } else {
                        // return _orig_send_attachment.apply( this, [props, attachment] );
                        $("#file-upload").val(attachment.id);
                        // $("#file-upload").after('<div><img src="' + attachment.url + '" style="max-width:150px;max-height:150px;"/></div>');
                        $('#profile_image').html('<img src="' + attachment.url + '" style="max-width:150px;max-height:150px;"/>');
                    };
                }

                wp.media.editor.open(button);
                return false;
            });

            $('.add_media').on('click', function(){
                _custom_media = false;
            });
        });

        $(document).on('submit', '#frmEditProfile', function(event) {
            // event.preventDefault();
            var user_nicename = $('#user_nicename').val();
            var first_name = $('#first_name').val();
            var last_name = $('#last_name').val();            
            var gender = $('#gender').val();
            var prev_profile_image = $('#hide_profile_picture').val();

            var _return = true;

            if($('.validate').length) {
                $('.validate').remove();
            }

            if(user_nicename == '') {
                $('#user_nicename').after('<div class="validate error">Please enter profile display name.</div>');
                _return = false;
            }

            if(first_name == '') {
                $('#first_name').after('<div class="validate error">Please enter first name.</div>');
                _return = false;
            }

            if(last_name == '') {
                $('#last_name').after('<div class="validate error">Please enter last name.</div>');
                _return = false;
            }

            if(gender == '') {
                $('#gender').after('<div class="validate error">Please select your gender.</div>');
                _return = false;
            }

            if(prev_profile_image == '') {
                $('#custom-file-upload').after('<div class="validate error">Please upload a profile image.</div>');
                _return = false;
            }

            return _return;
        });
    });
</script>