<form method="POST" id="frontend-form-1" class="frontend-post-form wp-ref" enctype="multipart/form-data">    
    <?php if((isset($_GET['post'])) && ($_GET['post'] == 'published')):
        echo "<div class='success'><i class=\"fa fa-check\" aria-hidden=\"true\"></i>&nbsp;Success! Your post has been published.</div><div style='margin:10px 0 0 0;'></div>";        
    endif; ?>
    <!-- WPFEPP\Element_Containers\Frontend_Element_Container -->
    <!-- WPGurus\Forms\Elements\Text -->
    <div class="frontend-item-container" style="" data-element-key="post_title">
        <!-- WPGurus\Forms\Elements\Text -->
        <!-- <label for="frontend-form-1-post-data-post-title">Title</label> -->
        <div class="frontend-item-messages ">
        </div>
        <div class="frontend-form-field-container" style="">
            <input class="js-validated-field post-data-post-title cstm-input"
                name="title"
                id="frontend-form-1-post-data-post-title" type="text"
                value="<?= ((isset($edit_post))) ? $edit_post->post_title : '' ?>" placeholder="Enter post Title Here..."/>
        </div>
        <!-- /WPGurus\Forms\Elements\Text -->
    </div><!-- /WPGurus\Forms\Elements\Text --> 
    <div style="margin:8px 0;"></div>
    <div class="frontend-item-container" style="" data-element-key="title">
        <!-- WPGurus\Forms\select-audio\Text -->
        <!-- <label for="frontend-form-1-post-data-post-title">Title</label> -->
        <div class="frontend-item-messages ">
        </div>
        <div class="frontend-form-field-container select-holder" style="">
            <select name="format" id="post_format">
                <option value="">-- SELECT A FORMAT --</option>
                <option value="st" <?= ($edit_post->format == false) ? 'selected' : '' ; ?>>Standard</option>
                <?php if((isset($formats)) && (is_array($formats)) && (count($formats))): ?>
                <?php foreach($formats as $k => $v): ?>
                    <option value="<?= strtolower($v) ?>" <?= (isset($edit_post)) && (strtolower($edit_post->format) == strtolower($v)) ? 'selected' : '' ; ?>><?= ucwords($v) ?></option>
                <?php endforeach; ?>
                <?php endif; ?>
            </select>
        </div>
        <!-- /WPGurus\Forms\select-audio\Text -->
    </div><!-- /WPGurus\Forms\select-audio\Text --> 
    <div style="margin:8px 0;"></div>
    <div class="frontend-item-container" style="" data-element-key="post_title">
        <!-- WPGurus\Forms\select-video\Text -->
        <!-- <label for="frontend-form-1-post-data-post-title">Title</label> -->
        <div class="frontend-item-messages ">
        </div>
        <div class="frontend-form-field-container select-holder" style="">
            <select name="category" id="category">
                <option value="">-- SELECT A CATEGORY --</option>
                <?php if((isset($categories)) && (is_array($categories)) && (count($categories))): ?>
                <?php foreach($categories as $k => $v): ?>
                    <option value="<?= $v->term_id ?>" <?= ((isset($edit_post->category[0]->term_id)) && ($edit_post->category[0]->term_id == $v->term_id)) ? 'selected' : '' ; ?>><?= ucwords($v->name) ?></option>
                <?php endforeach; ?>
                <?php endif; ?>
            </select>
        </div>
        <!-- /WPGurus\Forms\select-video\Text -->
    </div><!-- /WPGurus\Forms\select-video\Text --> 
    <div style="margin:8px 0;"></div>
    <div class="frontend-item-container" style="" data-element-key="post_title">
        <!-- WPGurus\Forms\select-video\Text -->
        <!-- <label for="frontend-form-1-post-data-post-title">Title</label> -->
        <div class="frontend-item-messages ">
        </div>
        <div class="frontend-form-field-container" style="">
            <select name="tags[]" id="tags" multiple>
                <?php if((isset($tags)) && (is_array($tags)) && (count($tags))): ?>
                <?php foreach($tags as $k => $v): ?>
                    <option value="<?= $v->name ?>" <?= ((isset($edit_post->tags)) && (in_array(strtolower($v->name), $edit_post->tags))) ? 'selected' : '' ; ?>><?= ucwords($v->name) ?></option>
                <?php endforeach; ?>
                <?php endif; ?>
            </select>
        </div>
        <!-- /WPGurus\Forms\select-video\Text -->
    </div><!-- /WPGurus\Forms\select-video\Text --> 
    <div style="margin:8px 0;"></div>
    <!-- WPGurus\Forms\Elements\Rich_Text -->
    <div class="frontend-item-container" style=""
        data-element-key="post_content">
        <!-- WPGurus\Forms\Elements\Rich_Text --> 
        <!-- <label for="frontend-form-1-post-data-post-content">Content</label> -->
        <div class="frontend-item-messages ">
        </div>
        <div class="frontend-form-field-container" style="">
            <?php $content = (isset($edit_post->post_content)) ? $edit_post->post_content : '' ; ?>
            <?php wp_editor( $content, 'post_content', $settings = [
                'wpautop' => true, // use wpautop?
                'media_buttons' => true, // show insert/upload button(s)
                'textarea_name' => 'content', // set the textarea name to something different, square brackets [] can be used here                
                'buttons' => 'strong,em,link,block,del,ins,img,ul,ol,li,code,more',
                'quicktags' => true
            ] ); ?>
        </div>
        <!-- /WPGurus\Forms\Elements\Rich_Text -->
    </div><!-- /WPGurus\Forms\Elements\Rich_Text -->
    <!-- WPGurus\Forms\Elements\Textarea -->
    <div style="margin:8px 0;"></div>
    <!-- Set featured image -->
    <div id="labelFeaturedImage">
        <label for="file-upload" class="custom-file-upload" id="custom-file-upload"><i class="fa fa-picture-o" aria-hidden="true"></i><span class="border-line d-border-line">Set Featured Image</span></label>
        <!-- <input id="file-upload" name='upload' accept="image/*" type="file" style="display:none;"> -->
        <input type="hidden" id="file-upload" name="upload" value=""/>
    </div>    
    <div id="front_featured_image"><?= ((isset($edit_post->featured_image)) && ($edit_post->featured_image <> '')) ? '<img src="'.$edit_post->featured_image.'" style="width:100px;"/>' : '' ; ?></div>

    <div style="display:<?= ((isset($edit_post->format)) && (strtolower($edit_post->format) == 'video')) ? 'block' : 'none' ; ?>;" id="divVideoUrl" class="additional-option">
        <input type="text" name="video_url" id="video_url" value="<?= ((isset($edit_post->video_url))) ? $edit_post->video_url : '' ; ?>" class="cstm-input" placeholder="Enter Youtube URL"/>
        <input type="hidden" name="_video_url" value="field_53567516fdcd6" />
    </div>
    <div style="display:<?= ((isset($edit_post->format)) && (strtolower($edit_post->format) == 'audio')) ? 'block' : 'none' ; ?>;" id="divAudioUrl" class="additional-option">
        <textarea name="audio_shortcode" id="audio_shortcode" class="cstm-input" placeholder="Enter Audio Shortcode"><?= ((isset($edit_post->audio_shortcode))) ? $edit_post->audio_shortcode : '' ; ?></textarea>
        <input type="hidden" name="_audio_shortcode" value="field_53a2c865500c8" />
    </div>

    <div style="display:<?= ((isset($edit_post->format)) && (strtolower($edit_post->format) == 'quote')) ? 'block' : 'none' ; ?>;" id="divQuoteAuthor" class="additional-option">
        <textarea name="quote_author" id="quote_author" class="cstm-input" placeholder="Enter Author Name"><?= ((isset($edit_post->quote_author))) ? $edit_post->quote_author : '' ; ?></textarea>
        <input type="hidden" name="_quote_author" value="field_53562bcbed577" />
    </div>

    <div style="display:<?= ((isset($edit_post->format)) && (strtolower($edit_post->format) == 'link')) ? 'block' : 'none' ; ?>;" id="divExternalLink" class="additional-option">
        <textarea name="external_link" id="external_link" class="cstm-input" placeholder="Enter External Link"><?= ((isset($edit_post->external_link))) ? $edit_post->external_link : '' ; ?></textarea>
        <input type="hidden" name="_external_link" value="field_53ccc940146a3" />
    </div>

    <div style="display:<?= ((isset($edit_post->format)) && (strtolower($edit_post->format) == 'gallery')) ? 'block' : 'none' ; ?>;" id="divGalleryUrl" class="">
        <br/>
        <div style="margin:5px 0;">Upload Gallery Images</div>
        <div id="allGalleryImages">
            <label for="file-upload-gallery" class="custom-file-upload" id="custom-file-upload-gallery"><i class="fa fa-picture-o" aria-hidden="true"></i><span class="border-line d-border-line">Upload Multiple Images</span></label>
            <!-- <input id="file-upload-gallery" accept="image/*" name='upload_gallery[]' type="file" style="display:none;" multiple> -->
            <input type="hidden" name="upload_gallery" id="file-upload-gallery" value="<?= ((isset($edit_post->gallery_images)) && (is_array($edit_post->gallery_images)) && (count($edit_post->gallery_images))) ? implode(',', $edit_post->gallery_images) : '' ; ?>"/>
            <input type="hidden" name="_gallery_of_images" value="field_5356e6a603b30" />
        </div>
        <div id="gallery_images" style="display: flex;flex-direction: row;">
            <?php
                if((isset($edit_post->gallery_image_urls)) && (is_array($edit_post->gallery_image_urls)) && (count($edit_post->gallery_image_urls))) {
                    $images = '';
                    foreach($edit_post->gallery_image_urls as $k => $v) {
                        $images .= '<div style="margin:0 1px;"><img src="'.$v.'" style="max-height:50px;max-width:50px;"/></div>';
                    }
                    echo $images;
                }
            ?>
        </div>
    </div>
    <?php if(($voucher_id_used == '') && ($voucher_id_used <= 0)): ?>
    <div style="margin:8px 0;"></div>
    <!-- Set featured image -->
    <div id="labelVoucher">
        <?php if((isset($vouchers)) && (is_array($vouchers)) && (count($vouchers))): ?>
        <select name="_voucher" id="voucher_codes">
            <option value=""> -- SELECT A VOUCHER -- </option>            
            <?php foreach($vouchers as $k => $v): ?>
            <option value="<?= $v['_item_id'] ?>" data-disabled="<?= $v['_is_disabled'] ?>" data-reason="<?= $v['_reason'] ?>" data-description="<?= $v['_description'] ?>" data-posts="<?= $v['_no_of_posts'] ?>"><?= $v['_sku'] ?></option>
            <?php endforeach; ?>
            <option value="0">Other</option>            
        </select>
        <input type="hidden" name="_no_of_posts" id="_no_of_posts" value=""/>
        <?php else: ?>
            <div class="error">
                <div>You do not have any voucher please <a style='color:#000;' class='renew_link' href="https://test.golfero.news/en/shop/">Click here to purchase</a> voucher codes</div>
                <div>Alternatively, if you already know a valid code then you can put it below.</div>
            </div>
        <?php endif; ?>
        <div id="divOther" style="display:<?= (!(((isset($vouchers)) && (is_array($vouchers)) && (count($vouchers)))))? 'block' : 'none' ; ?>;margin:5px 0 0 0;">
            <input type="text" name="voucher_code" id="voucher_code" value="" class="cstm-input" placeholder="Please enter the code manually"/>
            <input type="hidden" name="_hidden_voucher" id="_hidden_voucher" value=""/>
        </div>
    </div>    
    <?php endif; ?>
    <!-- //Set featured image// -->
    <hr class="dark-blue-hr">
    <div id="btnActions">
        <?php if(isset($edit_post) == false): ?>
        <!-- WPGurus\Forms\Elements\Button --> 
        <a href="" id="preview-button" class="submit-button preview-btn">Preview</a>
        <!-- /WPGurus\Forms\Elements\Button -->
        <!-- WPGurus\Forms\Elements\Button --> 
        <button name="btnSubmit"
            id="frontend-form-1-main-submit-button" disabled class="submit-button publish-btn"
            value="submit-form">Publish</button>
        <!-- /WPGurus\Forms\Elements\Button -->
        <!-- WPGurus\Forms\Elements\Button --> 
        <a href="" id="save_as_draft" class="submit-button draft-btn">Save As Draft</a>
        <!-- /WPGurus\Forms\Elements\Button --><span
            class="frontend-form-icon frontend-icon-loading" id="loading_spinner" style="display:none;"><i
                class="fa fa-refresh fa-spin"></i></span>
        <span class="frontend-form-icon frontend-icon-success" style="display:none;"><i
                class="fa fa-check"></i></span>
        <span class="frontend-form-icon frontend-icon-error" style="display:none;"><i
                class="fa fa-times"></i></span>
        <!-- /WPFEPP\Element_Containers\Frontend_Element_Container -->
        <!-- WPGurus\Forms\Elements\Nonce --> <input name="frontend-form-1_nonce"
            id="frontend-form-1-nonce" class="frontend-form-1-nonce"
            value="2ceaf3fe06" type="hidden" />
        <!-- /WPGurus\Forms\Elements\Nonce -->
        <!-- WPGurus\Forms\Elements\Hidden --> <input name="form_id"
            id="frontend-form-1-form-id" class="form-id" type="hidden"
            value="frontend-form-1" />
        <!-- /WPGurus\Forms\Elements\Hidden -->
        <div id="draft-status"></div>
        <?php else: ?>
        <?php if(strtolower(get_post_status($post_id)) == 'draft'): ?>
        <button name="btnSubmit"
            id="frontend-form-1-main-submit-button" disabled class="submit-button preview-btn"
            value="submit-form">Publish</button>
        <?php endif; ?>
        <button name="btnSubmit"
            id="frontend-form-1-main-submit-button-save" class="submit-button publish-btn"
            value="submit-form">Update Post</button>
            <a href="<?= home_url(ICL_LANGUAGE_CODE.'/dashboard'); ?>" class="submit-button preview-btn">Cancel &amp; Return</a>
        <?php endif; ?>
        <input type="hidden" id="post_id" name="post_id" value="<?= ((isset($_GET['post'])) && ($_GET['post'] <> '')) ? $_GET['post'] : '0'; ?>"/>
        <input type="hidden" id="action" name="action" value="save_as_draft"/>
        <input type="hidden" id="ajax_url" value="<?= admin_url( 'admin-ajax.php' ) ?>"/>
    </div>
    
</form>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script>
    $(document).ready(function() {
        function readURL(input) {
            if (input.files && input.files[0]) {
                var file_name = input.files[0].name;
                var extension = file_name.split('.').pop().toLowerCase();

                if((extension == 'jpg') || (extension == 'jpeg') || (extension == 'png') || (extension == 'gif')) {
                    var reader = new FileReader();

                    reader.onload = function (e) {                        
                        $('#front_featured_image').html('<img src="'+e.target.result+'" style="width:150px;"/>');
                    }

                    reader.readAsDataURL(input.files[0]);
                } else {
                    alert('Error! Only images are allowed to upload.');
                }
            }
        }

        function readMultiURL(input, placeToInsertImagePreview) {
            if (input.files) {
                var filesAmount = input.files.length;
                var container_html = '';

                $('#' + placeToInsertImagePreview).html(container_html);

                for (i = 0; i < filesAmount; i++) {
                    var file_name = input.files[i].name;
                    var extension = file_name.split('.').pop().toLowerCase();
                    
                    if((extension == 'jpg') || (extension == 'jpeg') || (extension == 'png') || (extension == 'gif')) {
                        var reader = new FileReader();                   
                    
                        reader.onload = function(event) {                        
                            container_html += '&nbsp; <a href="' +event.target.result+ '" target="_blank"><img style="max-width:100px;max-height:100px;" src="' +event.target.result+ '"></a>';
                            $('#' + placeToInsertImagePreview).html(container_html);
                        }
                        reader.readAsDataURL(input.files[i]);
                    }
                    
                }
                
            }
        }

        $(document).on('change', '#file-upload', function() {
            readURL(this);
        });

        $(document).on('change', '#file-upload-gallery', function() {
            readMultiURL(this, 'gallery_images');
        });
    });

    $(document).on('change', '#post_format', function() {
        $('.additional-option').hide();
        if($(this).val() == 'video') {
            $('#divVideoUrl').show();
        }
        if($(this).val() == 'link') {
            $('#divExternalLink').show();
        }
        if($(this).val() == 'quote') {
            $('#divQuoteAuthor').show();
        }
        if($(this).val() == 'audio') {
            $('#divAudioUrl').show();
        }
        if($(this).val() == 'gallery') {
            $('#divGalleryUrl').show();
        }
    });

    $(document).on('click', '#preview-button', function(event) {
        event.preventDefault();
        saveDraft($('#save_as_draft'), true);
    });    

    $(document).on('click', '#save_as_draft', function(event) {
        event.preventDefault();
        saveDraft(this);
    });

    $(document).on('blur', '#voucher_code', function() {
        validateManualVoucher();
    });

    function validateManualVoucher() {
        var voucher_code = $('#voucher_code').val();
        $('#voucher_code').after('<div class="validate-manual-voucher">Validating the voucher, please wait...</div>');
        $.ajax({
            url: $('#ajax_url').val(),
            type: "GET",
            dataType : "JSON",
            data: {
                action: 'validate_manual_voucher',
                voucher_code: voucher_code
            }
        }).
        done(function(response) {
            if($('.validate-manual-voucher').length) {
                $('.validate-manual-voucher').remove();
            }

            $('#frontend-form-1-main-submit-button').attr("disabled", true);
            var class_name = 'error';
            if(response.status == '1') {
                class_name = 'success';
                $('#_hidden_voucher').val(response.voucher_id);
                $('#frontend-form-1-main-submit-button').attr("disabled", false);
            }
            $('#voucher_code').after('<div class="' +class_name+ ' validate-manual-voucher">' + response.description + '</div>');
        }).
        fail(function(){
            alert('Error! A network issue found while validating the voucher code.');
        }).responseJSON;
    }

    function saveDraft(element, preview = false) {
        var is_valid = validation();                
        if(is_valid) {
            if(preview) {
                $(element).after('<span id="loader"><i class="fa fa-refresh fa-spin"></i> Please Wait.. Loading the preview. Make sure pop-up is not blocked</span>');
            } else {
                $(element).after('<span id="loader"><i class="fa fa-refresh fa-spin"></i> Saving as draft... please wait..</span>');
            }
            
            var fd = new FormData($('#frontend-form-1')[0]);            
            fd.append( "action", 'save_as_draft');
            // fd.append( "upload", $('#file-upload')[0].files[0]);
            $.ajax({
                url: $('#ajax_url').val(),
                type: "POST",
                dataType : "JSON",
                data: fd,
                processData: false,
                contentType: false,
                // data: {
                //     action: 'save_as_draft',
                //     //data: $('#frontend-form-1').serialize()
                //     title: $('#frontend-form-1-post-data-post-title').val(),
                //     post_format: $('#post_format').val(),
                //     category: $('#category').val(),
                //     tags: $('#tags').val(),
                //     content: $('#post_content').val(),
                //     upload: $('#file-upload').val(),
                //     post_id: $('#post_id').val(),
                //     // title: $('#frontend-form-1-post-data-post-title').val(),
                //     // title: $('#frontend-form-1-post-data-post-title').val(),
                //     // title: $('#frontend-form-1-post-data-post-title').val(),
                //     // title: $('#frontend-form-1-post-data-post-title').val(),
                // },
                // contentType: false,
                // processData: false,
            }).
            done(function(response) {
                // response = JSON.parse(response);
                $('#post_id').val(response.post_id);
                // console.log(response); return false;
                $('#loader').remove();
                if(preview) {
                    $(element).after('<div id="divLinkToPreview" style="display:none;"><a target="_blank" id="linkToPreview" href="' + response.url + '&preview=true"></a></div>');
                    $('#linkToPreview')[0].click();
                } else {
                    var string_message = '<div class="' + response.class + '">' + response.icon +' ' + response.message + '</div>';
                    $('#draft-status').html(string_message);
                    $("#loader").remove();
                    setTimeout(() => {
                        $('#draft-status').html('');
                    }, 3000);
                }
            }).
            fail(function(){
               alert('Error! A network issue found while saving your post.');
            }).responseJSON;
        }
    }

    // $(document).on('click', '.hidden-xs', function(event) {
        
    //     alert('asd');
    //     if($('body').hasClass('reading-mode') == false) {
    //         $('.page-title .fa').removeClass('fa-check');
    //         $('.page-title .fa').addClass('fa-plus');
    //         $('.page-title span').html('Add New Post +');
    //         $('.single-post-top-reading-mode span').html('ENTER READING MODE');
    //     }
    //     event.preventDefault();
    //     return false;
    // });

    function validation() {
        if($('.error').length) {
            $('.error').remove();
        }

        var _return = true;

        if($('#frontend-form-1-post-data-post-title').val().trim() == '') {
            $('#frontend-form-1-post-data-post-title').parent().after('<div class="error">Error! Post title is required.</div>');
            _return = false;
        }

        if($('#post_format').val().trim() == '') {
            $('#post_format').parent().after('<div class="error">Error! Please select a Format.</div>');
            _return = false;
        }

        if($('#category').val() == '') {
            $('#category').parent().after('<div class="error">Error! Please select a Post Category.</div>');
            _return = false;
        }

        if($('#tags').find('option:selected').length <= 0) {
            $('#tags').parent().after('<div class="error">Error! Please select at least one Tag..</div>');
            _return = false;
        }

        if(($('#post_id').val() == '') || ($('#post_id').val() == '0')) {
            if($('#file-upload').val().trim() == '') {
                $('#file-upload').after('<div class="error">Error! Upload an Image for your Post.</div>');
                _return = false;
            }
        }        

        if($('#post_format').val().toLowerCase() == 'video') {
            if($('#video_url').val().trim() == '') {
                $('#video_url').after('<div class="error">Error! Please enter the URL of your video.</div>');
                _return = false;
            }
        } else if($('#post_format').val().toLowerCase() == 'audio') {
            if($('#audio_shortcode').val().trim() == '') {
                $('#audio_shortcode').after('<div class="error">Error! Please enter the audio shortcode.</div>');
                _return = false;
            }
        } else if($('#post_format').val().toLowerCase() == 'quote') {
            if($('#quote_author').val().trim() == '') {
                $('#quote_author').after('<div class="error">Error! Please enter the author of the quote.</div>');
                _return = false;
            }
        } else if($('#post_format').val().toLowerCase() == 'link') {
            if($('#external_link').val().trim() == '') {
                $('#external_link').after('<div class="error">Error! Please enter the external link.</div>');
                _return = false;
            }
        } else if($('#post_format').val().toLowerCase() == 'gallery') {
            if($('#file-upload-gallery').val().trim() == '') {
                $('#file-upload-gallery').after('<div class="error">Error! Please select at least one image in your gallery.</div>');
                _return = false;
            }
        }
        
        return _return;
    }
    $(document).on('submit', '#frontend-form-1', function(event) {
        return validation();
    });
    
    jQuery(document).ready(function($){
		var _custom_media = true,
		_orig_send_attachment = wp.media.editor.send.attachment;

		$('#custom-file-upload').click(function(e) {
			var send_attachment_bkp = wp.media.editor.send.attachment;
			var button = $(this);
			// var id = button.attr('id').replace('_button', '');
            var id = 'file-upload';
			_custom_media = false;
			wp.media.editor.send.attachment = function(props, attachment){
				if ( _custom_media ) {
					$("#"+id).val(attachment.url);
				} else {
					// return _orig_send_attachment.apply( this, [props, attachment] );
                    $("#file-upload").val(attachment.id);
                    // $("#file-upload").after('<div><img src="' + attachment.url + '" style="max-width:150px;max-height:150px;"/></div>');
                    $('#front_featured_image').html('<img src="' + attachment.url + '" style="max-width:150px;max-height:150px;"/>');
				};
			}

			wp.media.editor.open(button);
			return false;
		});

		$('.add_media').on('click', function(){
			_custom_media = false;
		});
	});

    jQuery(document).ready(function($){
		var _custom_media = true,
		_orig_send_attachment = wp.media.editor.send.attachment;

		$('#custom-file-upload-gallery').click(function(e) {
			var send_attachment_bkp = wp.media.editor.send.attachment;
			var button = $(this);
			// var id = button.attr('id').replace('_button', '');
            var id = 'file-upload-gallery';
			_custom_media = true;
			wp.media.editor.send.attachment = function(props, attachment){
				if ( _custom_media ) {
					// $("#"+id).val(attachment.url);
                    // return _orig_send_attachment.apply( this, [props, attachment] );
                    var file_upload_gallery = $("#file-upload-gallery").val();
                    file_upload_gallery = file_upload_gallery.replace(/(^,)|(,$)/g, "");
                    file_upload_gallery = file_upload_gallery + ',' +attachment.id
                    file_upload_gallery = file_upload_gallery.replace(/(^,)|(,$)/g, "");
                    $("#file-upload-gallery").val(file_upload_gallery);
                    var gallery_images = $('#gallery_images').html();
                    $('#gallery_images').html(gallery_images + '<div style="margin:0 1px;"><img src="' + attachment.url + '" style="max-height:50px;max-width:50px;"/></div>');
				} else {
					// return _orig_send_attachment.apply( this, [props, attachment] );
                    var file_upload_gallery = $("#file-upload-gallery").val();
                    file_upload_gallery = file_upload_gallery.replace(/(^,)|(,$)/g, "");
                    file_upload_gallery = file_upload_gallery + ',' +attachment.id
                    file_upload_gallery = file_upload_gallery.replace(/(^,)|(,$)/g, "");
                    $("#file-upload-gallery").val(file_upload_gallery);
				};
			}

			wp.media.editor.open(button);
			return false;
		});

		$('.add_media').on('click', function(){
			_custom_media = false;
		});
	});

    $(document).ready(function() {
        $(document).on('change', '#voucher_codes', function() {
            if($('.voucher_message').length) {
                $('.voucher_message').remove();
            }
            var is_disabled = $('#voucher_codes').find(':selected').data('disabled');
            var reason = $('#voucher_codes').find(':selected').data('reason');
            var description = $('#voucher_codes').find(':selected').data('description');
            var _no_of_posts = $('#voucher_codes').find(':selected').data('posts');
            
            $('#divOther').hide();

            if($(this).prop('selectedIndex') > 0) {
                if($('#voucher_codes').val() == '0') {
                    $('#divOther').show();
                } else {
                    if(is_disabled) {
                        $('#voucher_codes').after('<div class="voucher_message error" style="margin:3px 0;"><div>'+reason+'</div>');
                        $('#frontend-form-1-main-submit-button').attr("disabled", true);
                        $('#_no_of_posts').val('0');
                    } else {
                        $('#voucher_codes').after('<div class="voucher_message success" style="margin:3px 0;">'+description+'</div>');
                        $('#frontend-form-1-main-submit-button').attr("disabled", false);
                        $('#_no_of_posts').val(_no_of_posts);
                    }
                }
                
            } else {
                $('#voucher_codes').after('<div class="voucher_message error" style="margin:3px 0;">Please select a voucher code from the list!</div>');
                $('#frontend-form-1-main-submit-button').attr("disabled", true);
                $('#_no_of_posts').val('0');
            }
            
        });

        $(document).on('click', '.renew_link', function(event) {
            event.preventDefault();
            if(confirm('Please make sure that you have saved the post as DRAFT, Unsaved posts will be lost. To save as draft, please click on "Cancel" below & then at the bottom of the form you have the option.')) {
                window.location.href = $(this).attr('href');
            }
        });
    });
</script>