<div class="mg_pad_left_right_30">
    <div class="mg_container" style="width:100%;">
        <div class="mg_w_70 mg_pad_right_3" style="width:100%;">
            <article class="pluto-page-box">
                <div class="mg_pad_left_right_top_bottom_30">
                    <div class="post-content" style="font-size:12px;line-height:14px;">
                        <h1 class="page-title" style="font-size:20px;margin:3px 0 30px 0;padding:8px 0;"><?= strtoupper($title) ?></h1>
                        <table width="100%" cellpadding="0" cellspacing="0">                        
                        <?php if((isset($vouchers)) && (is_array($vouchers)) && (count($vouchers))): ?>
                        <tr>
                            <th width="15%" style="text-align:center;">Voucher</th>
                            <th width="15%" style="text-align:center;">Order Details</th>
                            <th width="30%" style="text-align:center;">Valid Till</th>
                            <th width="15%" style="text-align:center;">Total Posts</th>
                            <th width="15%" style="text-align:center;">Available Posts</th>
                        </tr>
                        <tr><td colspan="5"><hr/></td></tr>
                        <?php foreach($vouchers as $k => $v): ?>
                        <tr>
                            <td style="text-align:center;"><?= $v->voucher_code ?></td>
                            <td style="text-align:center;"><?= '#'.$v->order_id.' ('.$v->order_status.')' ?></td>
                            <td style="text-align:center;"><?= date('M j, Y', strtotime($v->validity)) ?></td>
                            <td style="text-align:center;"><?= $v->no_of_posts ?></td>
                            <td style="text-align:center;"><?= $v->available_post ?></td>
                        </tr>
                        <tr><td colspan="5"><hr/></td></tr>
                        <?php endforeach; ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="4"><div class="error">You have not purchased any voucher.</div></td>
                        </tr>
                        <?php endif; ?>
                        </table>
                        <div>
                            <a class="btn submit-button preview-btn" href="<?= get_site_url().'/'.ICL_LANGUAGE_CODE.'/dashboard' ?>">&laquo; Return to Dashboard</a>
                            <?php $shop_page_url = get_permalink( woocommerce_get_page_id( 'shop' ) ); ?>
                            <a href="<?= $shop_page_url ?>" class="btn submit-button draft-btn">Buy More Voucher &raquo;</a>
                        </div>
                    </div>
                </div>
            </article>
        </div>
    </div>
</div>