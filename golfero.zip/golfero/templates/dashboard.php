<div class="mg_pad_left_right_30">
    <div class="mg_container" style="width:100%;">
        <div class="mg_w_70 mg_pad_right_3">
            <article class="pluto-page-box">
                <div class="mg_pad_left_right_top_bottom_30">
                    <div class="post-content" style="line-height:20px;">
                        <div class="mg_container">
                            <?php $user = wp_get_current_user(); ?>
                            <div class="mg_w_20 mg_pad_right_3 mg_pos_rel">
                                <?php $profile_picture = (get_user_meta($user->data->ID, 'profilepicture', true) <> '') ? get_user_meta($user->data->ID, 'profilepicture', true) : get_stylesheet_directory_uri().'/download.jpg'; ?>
                                <img src="<?= $profile_picture ?>" style="width:150px;"/>
                                <div class="mg_upload_image"><a href="<?= home_url(ICL_LANGUAGE_CODE.'/edit-profile') ?>">Edit Profile</a></div>
                            </div>
                            <div class="mg_w_80 mg_pad_left_12">                                
                                <h4><?= $user->data->user_nicename ?></h4>
                                <div><strong>Email</strong> : <?= $user->data->user_email ?></div>
                                <?php
                                    $first_name = get_user_meta($user->data->ID, 'first_name', true);
                                    $last_name = get_user_meta($user->data->ID, 'last_name', true);
                                    echo (($first_name <> '') && ($last_name <> '')) ? "<div><strong>Name</strong> : ".$first_name.' '.$last_name."</div>" : "";
                                ?>
                                <?php
                                    $gender = get_user_meta($user->data->ID, 'gender', true);
                                    echo (($gender <> '') && ($gender <> '')) ? "<div><strong>Gender</strong> : ".$gender."</div>" : "";
                                ?>
                                <div><strong>Password</strong> : ********** <a style="font-size:16px;" href="<?= home_url(ICL_LANGUAGE_CODE.'/change-password') ?>">Change Password</a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </article>
            <article class="pluto-page-box">
                <div class="mg_pad_left_right_top_bottom_30">
                    <?php if((isset($_GET['uploaded'])) && ($_GET['uploaded'] == '1')): ?>
                    <div class="success">The post has been added/updated successfully</div>
                    <?php elseif((isset($_GET['uploaded'])) && ($_GET['uploaded'] == '2')): ?>
                    <div class="success">The post has been deleted successfully</div>
                    <?php endif; ?>
                    <div class="post-content">
                        <div style="line-height:20px;font-size:14px;">
                            <h1 class="page-title" style="font-size:20px;margin:3px 0 30px 0;padding:8px 0;">YOUR UPLOADED POSTS</h1>
                            <table width="100%">
                                <tr style="border-bottom:1px solid #ccc;">
                                    <th style="width:25%;">POST</th>
                                    <th style="width:25%;">UPLOADED ON</th>
                                    <th style="width:20%;">VOUCHER</th>                                    
                                    <th style="width:20%;">PAYMENT</th>
                                    <th style="width:20%;">STATUS</th>
                                    <th style="width:10%;">OPTION</th>
                                </tr>
                                <?php if((isset($posts)) && (is_array($posts)) && (count($posts))): ?>
                                <?php foreach($posts as $k => $v): ?>
                                <tr style="border-bottom:1px solid #ccc;padding:5px 0;margin:15px 0;">
                                    <td><a href="<?= get_permalink($v->ID) ?>" title="<?= $v->post_title ?>" target="_blank"><?= (strlen(strip_tags($v->post_title)) > 15) ? substr(strip_tags($v->post_title), 0, 15).'...' : strip_tags($v->post_title) ?></a></td>
                                    <td><?= date('M j, Y', strtotime($v->post_modified)) ?></td>
                                    <?php
                                        $voucher_code = (isset($v->voucher)) ? $v->voucher->voucher_code : '-' ;
                                        $payment_status  = (isset($v->voucher->order_status)) ? $v->voucher->order_status : '' ;
                                    ?>
                                    <td>
                                        <div><strong><?= $voucher_code ?></strong></div>
                                    </td>
                                    <td><?= $payment_status ?></td>
                                    <td><?= $v->post_status ?></td>
                                    <td style="text-align:center;"><a href="<?php echo home_url(ICL_LANGUAGE_CODE.'/add-a-new-post?post='.$v->ID); ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>&nbsp;&nbsp;<a href="" class="trash-post" data-id="<?= $v->ID ?>"><i class="fa fa-trash" aria-hidden="true"></i></a></td>
                                </tr>
                                <?php endforeach; ?>
                                <?php else: ?>
                                <tr>
                                    <td colspan="4" style="margin:10px 0;"><div class="error">You have not posted any post!</div></td>
                                </tr>                                
                                <?php endif; ?>
                            </table>
                        </div>
                    </div>
                </div>
            </article>
        </div>
        <div class="mg_w_30 mg_pad_left_3">
            <article class="pluto-page-box">
                <div class="mg_pad_left_right_top_bottom_15">
                    <h1 class="page-title" style="font-size:20px;margin:3px 0 7px 0;padding:8px 0;">STATISTICS</h1>
                    <div class="post-content" style="line-height:20px;font-size:16px;">
                        <div><strong>Total Posts</strong> : <?= ((isset($all_posts)) && (is_array($all_posts)) && (count($all_posts))) ? count($all_posts) : '0' ?></div>
                        <div><strong>Draft</strong> : <?= ((isset($saved_posts)) && (is_array($saved_posts)) && (count($saved_posts))) ? count($saved_posts) : '0' ?></div>
                        <div><strong>Published</strong> : <?= ((isset($published_posts)) && (is_array($published_posts)) && (count($published_posts))) ? count($published_posts) : '0' ?></div>
                        <div><strong>On Hold</strong> : <?= ((isset($holded_posts)) && (is_array($holded_posts)) && (count($holded_posts))) ? count($holded_posts) : '0' ?></div>
                        <div><strong>Deleted</strong> : <?= ((isset($deleted_posts)) && (is_array($deleted_posts)) && (count($deleted_posts))) ? count($deleted_posts) : '0' ?></div>
                    </div>
                </div>
            </article>
            <article class="pluto-page-box">
                <div class="mg_pad_left_right_top_bottom_15">
                    <h1 class="page-title" style="font-size:20px;margin:3px 0 7px 0;padding:8px 0;">ORDER HISTORY</h1>
                    <div class="post-content" style="line-height:22px;font-size:15px;">                        
                        <?php if((isset($customer_orders)) && (is_array($customer_orders)) && (count($customer_orders))): ?>
                        <?php foreach($customer_orders as $k => $v): ?>
                        <?php
                            $order = wc_get_order($v->ID);
                            $public_view_order_url = esc_url( $order->get_view_order_url() );
                        ?>
                        <div><a href="<?= $public_view_order_url ?>"><?= 'Order no. #'.$v->ID.' dt. '.$order->get_date_created().' ('.$order->get_status().')' ?></a></div>
                        <hr/>
                        <?php endforeach; ?>
                        <?php else: ?>
                        <div class="error">You have no order history</div>
                        <?php endif; ?>
                        <div style="margin:15px 0 0 0;">[ <a href="<?= home_url(ICL_LANGUAGE_CODE.'/orders') ?>">View all orders</a> ]</div>
                    </div>
                </div>
            </article>
            <article class="pluto-page-box">
                <div class="mg_pad_left_right_top_bottom_15">
                    <h1 class="page-title" style="font-size:20px;margin:3px 0 7px 0;padding:8px 0;">VOUCHERS</h1>
                    <div class="post-content">
                        <?php if((isset($vouchers)) && (is_array($vouchers)) && (count($vouchers))): ?>
                        <?php foreach($vouchers as $k => $v): ?>
                        <div><?= $v->voucher_code ?></div>
                        <?php endforeach; ?>
                        <div style="margin:15px 0 0 0;">[ <a href="<?= home_url(ICL_LANGUAGE_CODE.'/vouchers') ?>">View all vouchers</a> ]</div>
                        <?php else: ?>
                        <div class="error">You do not have any voucher</div>
                        <?php endif; ?>
                    </div>
                </div>
            </article>
        </div>
    </div>
</div>
<input type="hidden" id="home_url" value="<?= home_url() ?>" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script>
    $(document).ready(function() {
        $(document).on('click', '.trash-post', function(event) {
            event.preventDefault();
            if(confirm('Are you sure to delete this post?')) {
                var url = $('#home_url').val() + 'dashboard?task=delete&id='+$(this).data('id');
                window.location.href = url;
            }
        });
    });
</script>