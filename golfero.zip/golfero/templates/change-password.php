<div class="mg_pad_left_right_30">
    <div class="mg_container">
        <div class="mg_w_70 mg_pad_right_3">
            <article class="pluto-page-box">
                <div class="mg_pad_left_right_top_bottom_30">
                    <div class="post-content" style="font-size:12px;line-height:14px;">
                        <form action="" method="post" id="frmChangePassword">
                        <h1 class="page-title" style="font-size:20px;margin:3px 0 30px 0;padding:8px 0;"><?= strtoupper($title) ?></h1>
                        <div>
                            <div>Current Password</div>
                            <div style="margin:3px 0 0 0;"><input type="password" placeholder="Current Password" name="current_password" id="current_password" style="width:60%;padding:5px 10px;" /></div>
                        </div>
                        <div style="margin:10px 0 0 0;">
                            <div>New Password</div>
                            <div style="margin:3px 0 0 0;"><input type="password" placeholder="New Password" name="new_password" id="new_password" style="width:60%;padding:5px 10px;" /></div>
                        </div>
                        <div style="margin:10px 0 0 0;">
                            <div>Confirm Password</div>
                            <div style="margin:3px 0 0 0;"><input type="password" placeholder="Confirm Password" name="confirm_password" id="confirm_password" style="width:60%;padding:5px 10px;" /></div>
                        </div>
                        <div style="margin:15px 0 0 0;">
                            <button type="submit" name="btnChangePassword" id="btnChangePassword" class="btn submit-button preview-btn">CHANGE PASSWORD</button>
                        </div>
                        </form>
                    </div>
                </div>
            </article>
        </div>
    </div>
</div>
<input type="hidden" id="ajax_url" value="<?= admin_url( 'admin-ajax.php' ) ?>"/>
<input type="hidden" id="site_url" value="<?= home_url( ICL_LANGUAGE_CODE ) ?>"/>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script>
    $(document).ready(function() {
        $(document).on('submit', '#frmChangePassword', function(event) {
            event.preventDefault();

            if($('.required').length) {
                $('.required').remove();
            }

            if($('.ajax_required').length) {
                $('.ajax_required').remove();
            }

            var current_password = $('#current_password').val();
            var new_password = $('#new_password').val();
            var confirm_password = $('#confirm_password').val();

            var _return = true;

            if(current_password.trim() == '') {
                $('#current_password').after('<div class="error required">* Current password is required</div>');
                _return = false;
            }

            if(new_password.trim() == '') {
                $('#new_password').after('<div class="error required">* New password is required</div>');
                _return = false;
            }

            if(confirm_password.trim() == '') {
                $('#confirm_password').after('<div class="error required">* Confirm password is required</div>');
                _return = false;
            }

            if((new_password.trim() != '') && (confirm_password.trim() != '') && (new_password.trim() != confirm_password.trim())) {
                $('#confirm_password').next('.required').remove();
                $('#confirm_password').after('<div class="error required">* New & Confirm password should be same.</div>');
                _return = false;
            }

            if(_return) {
                $('#btnChangePassword').after('<div class="ajax_required">Please wait...</div>');

                var fd = new FormData($('#frmChangePassword')[0]);            
                fd.append( "action", 'change_password');

                $.ajax({
                    url: $('#ajax_url').val(),
                    type: "POST",
                    dataType : "JSON",
                    data: fd,
                    processData: false,
                    contentType: false,                    
                }).
                done(function(response) {
                    if($('.ajax_required').length) {
                        $('.ajax_required').remove();
                    }
                    $('#btnChangePassword').after('<div style="margin:5px 0 0 0;" class="ajax_required"><div class="' + response.class + '" style="padding:5px 7px;">' + response.message + '</div></div>');

                    if(response.status == '1') {
                        $('#current_password').val('');
                        $('#new_password').val('');
                        $('#confirm_password').val('');

                        window.location.href = $('#site_url').val() + '/login';
                    } else {
                        setTimeout(function() {
                            $('.ajax_required').slideUp('slow');
                        }, 3000);
                    }
                }).
                fail(function(){
                    alert('Error! A network issue found while changing your password.');
                }).responseJSON;
            }
        });
    });
</script>