<div class="mg_pad_left_right_30">
    <div class="mg_container" style="width:100%;">
        <div class="mg_w_70 mg_pad_right_3" style="width:100%;">
            <article class="pluto-page-box">
                <div class="mg_pad_left_right_top_bottom_30">
                    <div class="post-content" style="font-size:12px;line-height:14px;">
                        <h1 class="page-title" style="font-size:20px;margin:3px 0 30px 0;padding:8px 0;"><?= strtoupper($title) ?></h1>
                        <div>
                            <table width="100%" cellspacing="0" cellpadding="0" border="0">
                            <?php if((isset($orders)) && (is_array($orders)) && (count($orders))): ?>
                            <tr>
                                <th style="text-align:center;">Order Details</th>
                                <th style="text-align:center;">Created On</th>
                                <th style="text-align:center;">Order Status</th>                                
                                <th style="text-align:center;">Total</th>
                                <th style="text-align:center;">&nbsp;</th>
                            </tr>
                            <tr><td colspan="5"><hr/></td></tr>
                            <?php foreach($orders as $k => $v): ?>
                            <?php
                                $order = wc_get_order( $v->ID );
                            ?>
                            <tr>
                                <td width="40%" style="text-align:center;">
                                    <?php
                                        $order_title = '#'.$v->ID.' '.$order->get_billing_first_name().' '.$order->get_billing_last_name();
                                        echo $order_title;
                                    ?>
                                </td>
                                <td width="17%" style="text-align:center;"><?= date('M d, Y', strtotime($order->get_date_created())) ?></td>
                                <td width="17%" style="text-align:center;"><?= $order->get_status(); ?></td>
                                <td width="16%" style="text-align:center;"><?= wc_price($order->get_total()); ?></td>
                                <td width="10%" style="text-align:center;"><a href="<?= get_site_url().'/'.ICL_LANGUAGE_CODE.'/view-order/'.$v->ID.'/' ?>">View Details</a></td>
                            </tr>
                            <tr><td colspan="5"><hr/></td></tr>
                            <?php endforeach; ?>
                            <?php else: ?>
                            <tr>
                                <td colspan="5"><div class="error">You have not completed any order.</div></td>
                            </tr>
                            <tr><td colspan="5"><hr/></td></tr>
                            <?php endif; ?>
                            </table>
                        </div>
                    </div>
                </div>
            </article>
        </div>
    </div>
</div>