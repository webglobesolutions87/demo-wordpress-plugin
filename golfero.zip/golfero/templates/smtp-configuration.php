<div class="wrap">
<h1><?= $title ?></h1>

<form method="post" action="options.php">
    <?php settings_fields( 'glofero-settings-group' ); ?>
    <?php do_settings_sections( 'glofero-settings-group' ); ?>
    <table class="form-table">
        <tr valign="top">
            <th scope="row">Enable SMTP Authentication</th>
            <td>
                <select name="golfero_enable_smtp">
                    <option value="0" <?= (esc_attr( get_option('golfero_enable_smtp') ) == '0') ? 'selected' : '' ; ?>>No</option>
                    <option value="1" <?= (esc_attr( get_option('golfero_enable_smtp') ) == '1') ? 'selected' : '' ; ?>>Yes</option>
                </select>
                <div style="font-size:11px;width:50%;"><strong>NOTE </strong>: You can enable or disable SMTP authentication while sending email. 
                Enabling &amp; Configuring SMTP will cause any email to be SMTP verified &amp; for SMTP verification you do not need to install any other plugin.</div>
            </td>
        </tr>

        <tr valign="top">
            <th scope="row">Host</th>
            <td>
                <input type="text" placeholder="mail.example.com" name="golfero_smtp_host" id="golfero_smtp_host" value="<?= esc_attr( get_option('golfero_smtp_host') ) ?>">
            </td>
        </tr>

        <tr valign="top">
            <th scope="row">Port</th>
            <td>
                <input type="text" placeholder="25, 8025, 2525, 587 or any other, see your webmail config." name="golfero_smtp_port" id="golfero_smtp_port" value="<?= esc_attr( get_option('golfero_smtp_port') ) ?>">
            </td>
        </tr>

        <tr valign="top">
            <th scope="row">SMTP Secure</th>
            <td>
                <select name="golfero_smtp_secure" id="golfero_smtp_secure">
                    <option value="tls" <?= (esc_attr( get_option('golfero_smtp_secure') ) == 'tls') ? 'selected' : '' ; ?>>TLS</option>
                    <option value="ssl" <?= (esc_attr( get_option('golfero_smtp_secure') ) == 'ssl') ? 'selected' : '' ; ?>>SSL</option>
                </select>
            </td>
        </tr>

        <tr valign="top">
            <th scope="row">Enable SMTP Debug</th>
            <td>
                <select name="golfero_smtp_debug" id="golfero_smtp_debug">
                    <option value="0" <?= (esc_attr( get_option('golfero_smtp_debug') ) == '0') ? 'selected' : '' ; ?>>No</option>
                    <option value="2" <?= (esc_attr( get_option('golfero_smtp_debug') ) == '2') ? 'selected' : '' ; ?>>Yes</option>
                </select>
            </td>
        </tr>

        <tr valign="top">
            <th scope="row">Username</th>
            <td>
                <input type="text" placeholder="SMTP username" name="golfero_smtp_username" id="golfero_smtp_username" value="<?= esc_attr( get_option('golfero_smtp_username') ) ?>">
            </td>
        </tr>

        <tr valign="top">
            <th scope="row">Password</th>
            <td>
                <input type="password" placeholder="SMTP password" name="golfero_smtp_password" id="golfero_smtp_password" value="<?= esc_attr( get_option('golfero_smtp_password') ) ?>">
            </td>
        </tr>

        <tr><td colspan="2" style="width:70%;"><hr/></td></tr>

        <tr valign="top">
            <th scope="row">From (Email Address)</th>
            <td>
                <input type="text" placeholder="Enter the email ID where the email to be sent from" name="golfero_smtp_from_email" id="golfero_smtp_from_email" value="<?= esc_attr( get_option('golfero_smtp_from_email') ) ?>">
            </td>
        </tr>

        <tr valign="top">
            <th scope="row">From (Name)</th>
            <td>
                <input type="text" placeholder="From - Name to be displayed to the user email" name="golfero_smtp_from_name" id="golfero_smtp_from_name" value="<?= esc_attr( get_option('golfero_smtp_from_name') ) ?>">
            </td>
        </tr>
    </table>
    
    <?php submit_button(); ?>

</form>
</div>