<?php
    namespace GLF\Foundations;

    // No direct access
    if (!defined('WPINC')) die;

    // Load the Template class
    use GLF\Templates\Template;
    // Load the Database operations related to database for THEME Supported POSTS
    use GLF\Posts\Post;
    // Load the Profile Class
    use GLF\Profile\Profile;
    // Load the Order Class
    use GLF\Order\Order;
    // Load the Voucher Class
    use GLF\Voucher\Voucher;
    // Load the Admin Class
    use GLF\Admin\Admin;
    
    /**
     * This class is the backbone of the plugin
     */
    class MG_Golfero {
        // The property/variable which holds the instance of the Template
        var $Template;
        // Related all posts
        var $Post;
        // Related all profile detail
        var $Profile;
        // Related all voucher info
        var $Voucher;
        // Related all admin options
        var $Admin;

        // Do essential dependency injections in the construct
        public function __construct() {
            $this->Template = new Template();
            $this->Post = new Post();
            $this->Profile = new Profile();
            $this->Order = new Order();
            $this->Voucher = new Voucher();
            $this->Admin = new Admin();

            add_action('wp_enqueue_scripts', array($this, 'add_media_upload_scripts'));
            add_filter( 'ajax_query_attachments_args', array($this, 'wpb_show_current_user_attachments'));
            add_action( 'init', array($this, 'authenticateAccess') );
        }

        public function add_media_upload_scripts() {
            if ( is_admin() ) {
                 return;
               }
            wp_enqueue_media();
        }

        /**
         * checks whether the user is logged in or not for pages like dashboard, edit page etc.
         * @param void takes no parameter
         * @return void returns nothing but redirects the user to the log in page if already not logged in
         */
        public function authenticateAccess() {
            // List the pages required login
            $pages = [
                'dashboard',
                'edit-profile',
                'change-password',
                'orders',
                'view-order',
                'vouchers'
            ];
            // access the current page url
            $request_uri_arr = explode('/', trim($_SERVER['REQUEST_URI'], '/'));
            // if the current page needs to be authenticated
            if(in_array($request_uri_arr[1], $pages)) {
                if(!is_user_logged_in()) { // If the user is not loggedin
                    // redirect the users to the login page
                    echo "<script>";
                    echo "window.location.href = '".home_url(ICL_LANGUAGE_CODE.'/login')."';";
                    echo "</script>";
                    exit();
                }
            }
        }

        /**
         * This function restricts the users to access files uploaded by others
         * However the user can access all media items uploaded by him/her
         * @param array the query parameter
         * @return array returns the modified query array
         */
        public function wpb_show_current_user_attachments($query) {
            // Filter the query with the current user id
            $user_id = get_current_user_id();
            $query['author'] = $user_id;
            return $query;
        }
    }
?>