<?php
namespace GLF\Profile;

// Load the Template class
use GLF\Templates\Template;

// No direct access
if (!defined('WPINC')) die;

class Profile {
    // Load the template class
    var $Template;

    public function __construct() {
        // Add all short-codes for user profile
        $this->shortcodeGenerate();
        // Initiate all wordpress hooks for user profile
        $this->initiateHook();
        $this->Template = new Template();
    }

    /**
     * dashboard page
     * @param void takes no parameter
     * @return void does not return anything
     */
    public function dashboard() {
        $data['text'] = 'My Dashboard';

        if((isset($_GET['task'])) && ($_GET['task'] == 'delete') && (isset($_GET['id'])) && ($_GET['id'] <> '')) {
            wp_trash_post($_GET['id']);
            echo "<script>";
            echo "window.location.href = '".home_url('/dashboard/?uploaded=2')."';";
            echo "</script>";
            exit();
        }

        // fetch the user id
        $user_id = get_current_user_id();
        // Lists the posts with status, payment status etc
        $posts = get_posts( array(
            'numberposts' => -1,
            'author'    => $user_id,
            'post_type'   => 'post',
            'order' => 'ID',
            'order_by' => 'DESC',
            'post_status' => array('publish', 'pending', 'draft', 'future', 'private', 'inherit')
        ) );
        
        // If there are posts for the user
        // The purpose of this block is to get the voucher information associated with this post
        if((isset($posts)) && (is_array($posts)) && (count($posts))) {
            global $wpdb;
            foreach($posts as $k => $v) { // Loop through the posts
                // Get the voucher id
                $voucher_id = get_post_meta($v->ID, '_voucher_id', true);
                // Now fetch the inforation regarding the voucher
                $results = $wpdb->get_results( "SELECT * FROM `".$wpdb->prefix."voucher_codes` WHERE voucher_id = ".$voucher_id);
                // Check if the voucher does exist
                if((isset($results)) && (is_array($results)) && (count($results) == 1)) {
                    // Now fetch the order detail
                    if(($results[0]->order_id <> '') && ($results[0]->order_id > 0)) { // Order id validation
                        // Get the order details from the order id
                        $order = wc_get_order( $results[0]->order_id );
                        
                        if(is_object($order)) { // Order id verification                                
                            // Store the order status into the result object
                            $results[0]->order_status = $order->get_status();
                        }                            
                    }
                    // Now add an extra property to the posts object as "voucher"
                    $posts[$k]->voucher = $results[0];
                }
            }
        }
        $data['posts'] = $posts;

        $all_posts = get_posts( array(
            'author'    => $user_id,
            'post_type'   => 'post',
            'post_status' => array('publish', 'pending', 'draft', 'future', 'private', 'inherit', 'trash')
        ) );
        $data['all_posts'] = $all_posts;

        $saved_posts = get_posts( array(
            'author'    => $user_id,
            'post_type'   => 'post',
            'post_status' => array('draft')
        ) );
        $data['saved_posts'] = $saved_posts;

        $published_posts = get_posts( array(
            'author'    => $user_id,
            'post_type'   => 'post',
            'post_status' => array('publish')
        ) );
        $data['published_posts'] = $published_posts;

        $holded_posts = get_posts( array(
            'author'    => $user_id,
            'post_type'   => 'post',
            'post_status' => array('pending')
        ) );
        $data['holded_posts'] = $holded_posts;

        $deleted_posts = get_posts( array(
            'author'    => $user_id,
            'post_type'   => 'post',
            'post_status' => array('trash')
        ) );
        $data['deleted_posts'] = $deleted_posts;

        // Get all customer orders
        $customer_orders = wc_get_orders( array(
            'limit' => 5,
            'customer_id' => $user_id,
            'status' => array('on-hold','processing','completed'),
        ) );
        $data['customer_orders'] = $customer_orders;
        
        // List last 5 vouchers in the dashboard
        // View all link is given to view all vouchers purchased by the user
        global $wpdb;
        $vouchers = $wpdb->get_results("SELECT * FROM `".$wpdb->prefix."voucher_codes` WHERE `user_id`=".$user_id.' ORDER BY `voucher_id` DESC LIMIT 0,5');
        $data['vouchers'] = $vouchers;

        // Call the template file with data
        $this->Template->render('dashboard', $data);
    }

    /**
     * short code for edit profile option
     * @param void takes no parameter
     * @return void returns nothing
     */
    public function editProfile() {
        $data = array();
        // Set the page title
        $data['title'] = 'Edit Profile';

        // retrieve the current logged in user id
        $user_id = get_current_user_id();

        // Get user details from the user table
        $user = get_userdata($user_id);
        $data['user'] = $user;

        // Get the first name of the user from the meta table
        $data['first_name'] = get_user_meta($user_id, 'first_name', true);
        $data['last_name'] = get_user_meta($user_id, 'last_name', true);
        $data['gender'] = get_user_meta($user_id, 'gender', true);
        $profile_picture = (get_user_meta($user_id, 'profilepicture', true) <> '') ? get_user_meta($user_id, 'profilepicture', true) : get_stylesheet_directory_uri().'/download.jpg';
        // $data['profilepicture'] will never be empty, i.e. if the image is not available then it will fetch the placeholder image
        $data['profilepicture'] = $profile_picture;
        // In edit mode we need to keep a validation which is - if the profile image is blank then we will force them to select an image
        // If the profile picture is already uploaded (i.e. it has a value) then it will not be mandatory to upload or change the picture
        $data['_profilepicture'] = get_user_meta($user_id, 'profilepicture', true);

        // Call the template file with data
        $this->Template->render('edit-profile', $data);
    }

    /**
     * Save profile details of any user
     * @param void takes nothing
     * @return void returns nothing
     */
    public function saveProfile() {
        $user_id = get_current_user_id();
        if(isset($_POST['btnEditProfile'])) {
            wp_update_user( array( 'ID' => $user_id, 'user_nicename' => $_POST['user_nicename'] ) );
            update_user_meta($user_id, 'first_name', $_POST['first_name']);
            update_user_meta($user_id, 'last_name', $_POST['last_name']);
            update_user_meta($user_id, 'gender', $_POST['gender']);
            if($_POST['profilepicture'] <> '') {
                update_user_meta($user_id, 'profilepicture', wp_get_attachment_url($_POST['profilepicture']) );
            }            
        }
        //ICL_LANGUAGE_CODE
        echo "<script>";
        echo "window.location.href = '".get_site_url()."/edit-profile?updated=1';";
        echo "</script>";
    }

    /**
     * layout for change password
     * @param void takes no parameter
     * @return void returns nothing
     */
    public function changePassword() {
        // Initialize the array to be sent to the template file
        $data = array();
        $data['title'] = 'Change Password';

        // Call the template file with data
        $this->Template->render('change-password', $data);
    }

    /**
     * AJAX call for saving the changed password
     * @param void takes no parameter
     * @return void returns nothing
     */
    public function ajaxChangePassword() {
        // Set default return values
        $return = [
            'status' => '0',
            'message' => 'Error! Could not change your password',
            'class' => 'error',
            'icon' => '<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>'
        ];

        if(isset($_POST['current_password'])) {
            // Store current password
            $current_password = sanitize_text_field($_POST['current_password']);
            // Store new password
            $new_password = sanitize_text_field($_POST['new_password']);
            // Store confirm password
            $confirm_password = sanitize_text_field($_POST['confirm_password']);

            // Fetch the current user id
            $user_id = get_current_user_id();
            // Get user details by id
            $user = get_user_by( 'ID', $user_id );

            // Wordpress built in function to check the entered current password is correct or not
            if(wp_check_password( $current_password, $user->data->user_pass, $user->ID)) { // If, Yes
                if($new_password == $confirm_password) { // Check if the new password matches with the confirmed password
                    // Change the current user's password
                    wp_set_password( $confirm_password, $user_id );
                    // Update the status message
                    $return['message'] = 'Password updated successfully';
                    // Update the display class name
                    $return['class'] = 'success';
                    // Set status true
                    $return['status'] = '1';
                } else {
                    // If new password & confirm password does not match.
                    $return['message'] = 'New & Confirm password should be same';    
                }
            } else {
                // If entered current password in incorrect
                $return['message'] = 'Incorrect current password entered';
            }
        }
        // return the array in json format
        echo json_encode($return);
        exit();
    }

    /**
     * List all shortcodes for user profile related function
     * @param void takes no parameter
     * @return void returns nothing
     */
    public function shortcodeGenerate() {
        // The dashboard
        add_shortcode('dashboard', array($this, 'dashboard'));
        // edit profile shortcode
        add_shortcode('edit_profile', array($this, 'editProfile'));
        // change password shortcode
        add_shortcode('change_password', array($this, 'changePassword'));
    }

    /**
     * Inititate the wordpress hooks associated with this profile
     * @param void takes nothing
     * @return void returns nothing
     */
    public function initiateHook() {
        // save the user profile details
        add_action('admin_post_save_profile_info', array($this, 'saveProfile'));
        // define the actions for the two hooks created, first for logged in users and the next for logged out users        
        add_action("wp_ajax_change_password", array($this, 'ajaxChangePassword'));
    }
}
?>