<?php
namespace GLF\Posts;

// No direct access
if (!defined('WPINC')) die;

class Post {
    public function __construct() {
        $this->initiateHook();
    }

    public function postTypes() {
        return get_post_types();
    }

    public function postCategories() {
        return get_categories([ 'hide_empty' => false ]);
    }

    public function postTags() {
        return get_tags();
    }

    public function postFormats() {
        return [
            'aside', 
            'image', 
            'video', 
            'audio', 
            'quote', 
            'link', 
            'gallery'
        ];
    }

    public function saveAsDraft() {
        $return = [
            'status' => false,
            'message' => 'Error! Could not save your post as draft',
            'class' => 'error',
            'icon' => '<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>'
        ];
        
        $title = $_REQUEST['title'];
        $format = $_REQUEST['format'];
        $category = $_REQUEST['category'];
        $tags = $_REQUEST['tags'];
        $content = $_REQUEST['content'];
        
        if($_REQUEST['post_id'] == '0') {
            
            $postId = wp_insert_post([
                'post_title' => $title,
                'post_content' => $content,
                'post_category' => [ '0' => $category ],
                'tags_input' => $tags,
                'post_status' => 'draft'
            ]);
            if($format <> 'st') {
                set_post_format($postId, $format);
            }           

            if($_REQUEST['upload'] <> '') {
                set_post_thumbnail( $postId, $_REQUEST['upload'] );
            }

            switch($format) {
                case "video":
                    add_post_meta($postId, '_video_url', $_REQUEST['_video_url']);
                    add_post_meta($postId, 'video_url', $_REQUEST['video_url']);
                break;
    
                case "audio":
                    add_post_meta($postId, '_audio_shortcode', $_REQUEST['_audio_shortcode']);
                    add_post_meta($postId, 'audio_shortcode', $_REQUEST['audio_shortcode']);
                break;
    
                case "quote":
                    add_post_meta($postId, '_quote_author', $_REQUEST['_quote_author']);
                    add_post_meta($postId, 'quote_author', $_REQUEST['quote_author']);
                break;
    
                case "link":
                    add_post_meta($postId, '_external_link', $_REQUEST['_external_link']);
                    add_post_meta($postId, 'external_link', $_REQUEST['external_link']);
                break;

                case "gallery":
                    if($_REQUEST['upload_gallery'] <> '') {
                        $upload_gallery_array = explode(',', trim($_REQUEST['upload_gallery'], ','));
                        $gallery_of_images = "a:".$total.":{";
                        $uploaded_gallery = false;

                        if((isset($upload_gallery_array)) && (is_array($upload_gallery_array)) && (count($upload_gallery_array))) {
                            foreach($upload_gallery_array as $k => $v) {
                                $gallery_of_images .= "i:".$k.";s:".strlen($v).":\"".$v."\";";
                                $uploaded_gallery = true;
                            }
                        }

                        $gallery_of_images .= '}';
                        $gallery_of_images = ($uploaded_gallery) ? $gallery_of_images : '' ;

                        add_post_meta($postId, '_gallery_of_images', $_REQUEST['_gallery_of_images']);

                        global $wpdb;
                        $wpdb->insert($wpdb->prefix . 'postmeta', array(
                            'post_id' => $postId,
                            'meta_key' => 'gallery_of_images',
                            'meta_value' => $gallery_of_images
                        ));
                    }
                break;
            }
        } else {
            $postId = $_REQUEST['post_id'];
            wp_update_post([
                'ID' => $_REQUEST['post_id'],
                'post_title' => $_REQUEST['title'],
                'post_content' => $_REQUEST['content'],
                'post_category' => $_REQUEST['category'],
                'tags_input' => $_REQUEST['tags']
            ]);
            if($_REQUEST['format'] <> 'st') {
                set_post_format($_REQUEST['post_id'], $_REQUEST['format']);
            }

            if($_REQUEST['upload'] <> '') {
                set_post_thumbnail( $postId, $_REQUEST['upload'] );
            }

            switch($format) {
                case "video":                    
                    if(metadata_exists('post', $postId, 'video_url')) {
                        update_post_meta($postId, '_video_url', $_REQUEST['_video_url']);
                        update_post_meta($postId, 'video_url', $_REQUEST['video_url']);
                    } else {
                        add_post_meta($postId, '_video_url', $_REQUEST['_video_url']);
                        add_post_meta($postId, 'video_url', $_REQUEST['video_url']);
                    }
                break;
    
                case "audio":                    
                    if(metadata_exists('post', $postId, 'audio_shortcode')) {
                        update_post_meta($postId, '_audio_shortcode', $_REQUEST['_audio_shortcode']);
                        update_post_meta($postId, 'audio_shortcode', $_REQUEST['audio_shortcode']);
                    } else {
                        add_post_meta($postId, '_audio_shortcode', $_REQUEST['_audio_shortcode']);
                        add_post_meta($postId, 'audio_shortcode', $_REQUEST['audio_shortcode']);
                    }
                break;
    
                case "quote":
                    if(metadata_exists('post', $postId, 'quote_author')) {
                        update_post_meta($postId, '_quote_author', $_REQUEST['_quote_author']);
                        update_post_meta($postId, 'quote_author', $_REQUEST['quote_author']);
                    } else {
                        add_post_meta($postId, '_quote_author', $_REQUEST['_quote_author']);
                        add_post_meta($postId, 'quote_author', $_REQUEST['quote_author']);
                    }                 
                break;
    
                case "link":
                    if(metadata_exists('post', $postId, 'external_link')) {
                        update_post_meta($postId, '_external_link', $_REQUEST['_external_link']);
                        update_post_meta($postId, 'external_link', $_REQUEST['external_link']);
                    } else {
                        add_post_meta($postId, '_external_link', $_REQUEST['_external_link']);
                        add_post_meta($postId, 'external_link', $_REQUEST['external_link']);
                    }
                break;

                case "gallery":
                    if($_REQUEST['upload_gallery'] <> '') {
                        $upload_gallery_array = explode(',', trim($_REQUEST['upload_gallery'], ','));
                        $gallery_of_images = "a:".count($upload_gallery_array).":{";
                        $uploaded_gallery = false;

                        if((isset($upload_gallery_array)) && (is_array($upload_gallery_array)) && (count($upload_gallery_array))) {
                            foreach($upload_gallery_array as $k => $v) {
                                $gallery_of_images .= "i:".$k.";s:".strlen($v).":\"".$v."\";";
                                $uploaded_gallery = true;
                            }
                        }

                        $gallery_of_images .= '}';
                        $gallery_of_images = ($uploaded_gallery) ? $gallery_of_images : '' ;

                        update_post_meta($postId, '_gallery_of_images', $_REQUEST['_gallery_of_images']);

                        global $wpdb;
                        if(metadata_exists('post', $postId, 'gallery_of_images')) {
                            $wpdb->update($wpdb->prefix . 'postmeta', array('meta_value'=>$gallery_of_images), array('post_id'=>$postId, 'meta_key'=>'gallery_of_images'));                            
                        } else {
                            $wpdb->insert($wpdb->prefix . 'postmeta', array(
                                'post_id' => $postId,
                                'meta_key' => 'gallery_of_images',
                                'meta_value' => $gallery_of_images
                            ));
                        }
                    }
                break;
            }
        }
        
        $return['status'] = true;
        $return['class'] = 'success';
        $return['icon'] = '<i class="fa fa-check" aria-hidden="true"></i>';
        $return['message'] = 'Success! Your post has been saved.';
        $return['post_id'] = $postId;
        $return['url'] = get_permalink($postId);

        echo json_encode($return);
        die();
    }

    /**
     * This function fetches all order history for a particular customer
     * @param void no parameter is required
     * @return array if the user has a paid product else empty array
     */
    public function hasActiveProduct() {

        // Initialize the return array
        $_return = array();

        // get the current logged in user_id
        $user_id = get_current_user_id();

        global $wpdb;

        // Get the list of voucher code for this user
        $codes = $wpdb->get_results( "SELECT * FROM `".$wpdb->prefix."voucher_codes` WHERE `user_id`=".get_current_user_id() );
        $shop_page_url = get_permalink( woocommerce_get_page_id( 'shop' ) );
        
        if((isset($codes)) && (is_array($codes)) && (count($codes))) {
            foreach($codes as $k => $v) {

                // Get the order detail
                $order = wc_get_order( $v->order_id );

                // check if the customer has a previous order history or not
                if((isset($order)) && (is_object($order))) {
                    // Now get the order status of the order
                    $order_status  = $order->get_status();

                    if(strtolower($order_status) == 'completed') {
                        $_valid_till = $v->validity;
                        $_no_of_posts = $v->available_post;
                        
                        $_return[$k]['_description'] = '';
                        $_return[$k]['_item_id'] = $v->voucher_id;
                        $_return[$k]['_sku'] = $v->voucher_code;
                        if(strtotime($_valid_till) < strtotime(date('Y-m-d'))) {
                            $_return[$k]['_is_disabled'] = '1';
                            $_return[$k]['_reason'] = 'The voucher(s) expired on '.$_valid_till.'. <a style=\'color:#000;\' class=\'renew_link\' href=\''.$shop_page_url.'\'>Click here to renew</a>';
                        } elseif($_no_of_posts <= 0) {
                            $_return[$k]['_is_disabled'] = '1';
                            $_return[$k]['_reason'] = 'The voucher does not have any post left. <a style=\'color:#000;\' class=\'renew_link\' href=\''.$shop_page_url.'\'>Click here to renew</a>';
                        } else {
                            $_return[$k]['_is_disabled'] = '0';
                            $_return[$k]['_reason'] = '';
                            $_return[$k]['_description'] = $_no_of_posts.' post(s) left, valid till '.$_valid_till;
                        }
                    }
                }                                
            }
        }
        // return the order history
        return $_return;
    }

    /**
     * adds a custom field in the general tab of woocommerce product add/edit page from the wp-admin
     * @param void takes no parameter
     * @return void only attaches a custom fild
     */
    public function addValidity() {
        // fetch the global post
        global $post;

        // prepare the html to output
        $return = '<p class="form-field _sale_price_field ">
        <label for="_sale_price">Validity for this Product</label><input type="number" class="short wc_input_price" style="" name="_validity" id="_validity" value="'.get_post_meta($post->ID, '_validity', true).'" placeholder=""  /> <span class="description">days</span></p>';
        $return .= '<p class="form-field _sale_price_field " style="margin:-15px 0 0 0;">
        <label for="_sale_price">&nbsp;</label>(All calculation is based on day(s) count, so, for a month just put 30 & for a year put 365</label></p>';

        $return .= '<p class="form-field _sale_price_field ">
        <label for="_sale_price">Number of posts allowed</label><input type="number" class="short wc_input_price" style="" name="_no_of_posts" id="_no_of_posts" value="'.get_post_meta($post->ID, '_no_of_posts', true).'" placeholder=""  /></p>';
        $return .= '<p class="form-field _sale_price_field " style="margin:-15px 0 0 0;">
        <label for="_sale_price">&nbsp;</label>Put the number of posts allowed for this product</label></p>';

        // echo it so it takes effect
        echo $return;
    }

    /**
     * Save the meta-data from the custom field
     * @param int accepts the product id (post-id)
     * @return void saves the metadata to the product meta
     */
    public function saveValidity($post_id) {
        $product = wc_get_product( $post_id );
        $_validity = isset( $_POST['_validity'] ) ? $_POST['_validity'] : '';
        $_no_of_posts = isset( $_POST['_no_of_posts'] ) ? $_POST['_no_of_posts'] : '';
        $product->update_meta_data( '_validity', sanitize_text_field( $_validity ) );
        $product->update_meta_data( '_no_of_posts', sanitize_text_field( $_no_of_posts ) );
        $product->save();
    }

    /**
     * Save the meta-data for the orders basically _valid_till & _no_of_posts
     * @param int the order id
     * @return void returns nothing
     */
    public function saveOrderMeta($order_id) {
        // First get the order
        $order = wc_get_order( $order_id );
        // Get the Items for this order
        $items = $order->get_items();
        
        // Lets check if the order is not empty
        if((isset($items)) && (is_array($items)) && (count($items))) {            
            // Loop through each item
            foreach($items as $item_id => $item) {
                // Get the product id
                $product_id = $item->get_product_id();
                
                // Get the validity for this product voucher
                $validity = get_post_meta($product_id, '_validity', true);
                // Now calculate the validity of this item for this order & user
                // generate today's date object
                $current_date=date('Y-m-d');
                // calculate the future date
                $_valid_till = date('Y-m-d', strtotime($current_date. ' + '.$validity.' days'));
                
                // Get the no of available posts for this product voucher
                $_no_of_posts = get_post_meta($product_id, '_no_of_posts', true);
                
                wc_update_order_item_meta( $item_id, '_valid_till', $_valid_till );
                wc_update_order_item_meta( $item_id, '_no_of_posts', $_no_of_posts );

                $voucher_code = 'VO'.date('y').date('m');
                for($i=0; $i<5; $i++) {
                    $rand = rand(1, 26);
                    $voucher_code .= $this->getAlphabetFromDigit($rand);
                }

                global $wpdb;
                $wpdb->insert($wpdb->prefix.'voucher_codes', array(
                    'voucher_code' => $voucher_code,
                    'user_id' => get_current_user_id(),
                    'order_id' => $order_id,
                    'validity' => $_valid_till,
                    'no_of_posts' => $_no_of_posts,
                    'available_post' => $_no_of_posts
                ));
            }
        }
    }

    /**
     * this function is required when forming the voucher code
     * @param int the digit itself
     * @return string/bool the character if valid input given else false
     */
    private function getAlphabetFromDigit($digit = '') {
        $alphabet_array = [ '1' => 'A', '2' => 'B', '3' => 'C', '4' => 'D', '5' => 'E',
            '6' => 'F', '7' => 'G', '8' => 'H', '9' => 'I', '10' => 'J','11' => 'K',
            '12' => 'L', '13' => 'M', '14' => 'N', '15' => 'O', '16' => 'P', '17' => 'Q',
            '18' => 'R', '19' => 'S', '20' => 'T', '21' => 'U', '22' => 'V', '23' => 'W',
            '24' => 'X', '25' => 'Y', '26' => 'Z',
        ];
        return ($digit <> '') ? $alphabet_array[$digit] : false ;
    }
    /**
     * validates the voucher code entered manually in AJAX method
     * @param void receives $_GET parameters
     * @return array json array
     */
    public function validateManualVoucher() {
        // Store the voucher code entered into the variable
        $voucher_code =$_GET['voucher_code'];

        // Prepare the return array
        $_return = [
            'status' => '0',
            'voucher_id' => '0',
            'description' => 'Invalid voucher code entered!'
        ];

        // the global variable
        global $wpdb;

        $vouchers = $wpdb->get_results("SELECT * FROM `".$wpdb->prefix."voucher_codes` WHERE `voucher_code`='".$voucher_code."'");
        if((isset($vouchers)) && (is_array($vouchers)) && (count($vouchers))) {
            
            // Need to validate the order status. i.e. if the order is completed then only the voucher should be validated.
            $order_id = $vouchers[0]->order_id;
            // Get the order
            $order = wc_get_order( $order_id );
            // Check if the order is valid or not
            if((isset($order)) && (is_object($order))) {
                // Fetch the order status
                $order_status  = $order->get_status();
                // Now check if the order is completed or not
                if((isset($order_status)) && (strtolower($order_status) == 'completed')) { // If the order status is completed
                    $shop_page_url = get_permalink( woocommerce_get_page_id( 'shop' ) );
                    if(strtotime($vouchers[0]->validity) < strtotime(date('Y-m-d'))) {
                        $_return['description'] = 'The voucher(s) expired on '.date('jS F, Y', strtotime($vouchers[0]->validity)).'. <a style=\'color:#000;\' class=\'renew_link\' href=\''.$shop_page_url.'\'>Click here to renew</a>';
                    } elseif($vouchers[0]->available_post <= 0) {
                        $_return['description'] = 'The voucher does not have any post left. <a style=\'color:#000;\' class=\'renew_link\' href=\''.$shop_page_url.'\'>Click here to renew</a>';
                    } else {
                        $_return['status'] = '1';
                        $_return['voucher_id'] = $vouchers[0]->voucher_id;
                        $_return['description'] = $vouchers[0]->available_post.' post(s) left, valid till '.date('jS F, Y', strtotime($vouchers[0]->validity));
                    }
                }
            }
            
        } else {
            $_return['description'] = "Invalid voucher code entered!";
        }

        echo json_encode($_return);
        exit();
    }

    /**
     * sends an email to the customer with the voucher code when the payment is completed
     * @param int order_id, id of the order
     * @return void returns nothing
     */
    public function paymentComplete($order_id) {        
        // Load global wordpress object
        global $wpdb;
        // List all voucher codes against the order id
        $voucher = $wpdb->get_results("SELECT * FROM `".$wpdb->prefix."voucher_codes` WHERE `order_id`=".$order_id);
        
        // If any voucher code exists
        if((isset($voucher)) && (is_array($voucher)) && (count($voucher))) {
            // All records for the order_id should have same user id, so we can access any recored to find the associated user_id
            // For convinience we are considering the first record
            $user_id = $voucher[0]->user_id;
            // Get the user detail associated with the user ID
            $user = get_user_by('ID', $user_id);

            // Prepare the HTML template to be sent
            $html = "<h4>Hello ".$user->user_nicename."</h4>";
            $html .= "<div>Your order #".$order_id." has been marked completed. Here are the coupon details that you have purchased</div><br/>";

            foreach($voucher as $k => $v) { // For multiple coupon there will be multiple row in the HTML template
                $html .= "<div><strong> Voucher Code</strong> : ".$v->voucher_code."</div>";
                $html .= "<div><strong> No. of Available Posts</strong> : ".$v->no_of_posts."</div>";
                $html .= "<div><strong> Valid Till</strong> : ".date('jS F, Y', strtotime($v->validity))."</div>";
            }
            // Prepare the header
            $headers = array('Content-Type: text/html; charset=UTF-8');           
            
            // Send the email to the user confirming the purchase is complete.
            wp_mail($user->user_email, "Vouchers you purchased in Golfero", $html, $headers);
        }
    }

    public function initiateHook() {
        // define the actions for the two hooks created, first for logged in users and the next for logged out users        
        add_action("wp_ajax_save_as_draft", array($this, 'saveAsDraft'));
        // add_action("wp_ajax_nopriv_save_as_draft", array($this, 'saveAsDraft'));
        // Add a custom field in the general tab of the product edit/add page from wp-admin
        add_action( 'woocommerce_product_options_general_product_data', array($this, 'addValidity') );
        // Save the custom field value for this product
        add_action( 'woocommerce_process_product_meta', array($this, 'saveValidity') );
        // Save the order meta data, for the order
        add_action( 'woocommerce_checkout_update_order_meta', array($this, 'saveOrderMeta') );
        // Send an email with voucher code to the user when the payment completes
        add_action( 'woocommerce_order_status_completed', array($this, 'paymentComplete'));
        // Validate the voucher code entered manually
        add_action("wp_ajax_validate_manual_voucher", array($this, 'validateManualVoucher'));
    }
}
?>