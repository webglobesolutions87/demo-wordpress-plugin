<?php
namespace GLF\Voucher;

// Load the Template class
use GLF\Templates\Template;

// No direct access
if (!defined('WPINC')) die;

class Voucher {
    // Load the template class
    var $Template;

    public function __construct() {
        // Add all short-codes for user profile
        $this->shortcodeGenerate();
        // Initiate all wordpress hooks for user profile
        $this->initiateHook();
        // Create the template object
        $this->Template = new Template();
    }

    /**
     * lists the voucher codes
     * @param void takes no parameter
     * @return void returns nothing
     */
    public function vouchers() {
        $data = array();
        $data['title'] = "List of Vouchers";

        // List all vouchers
        global $wpdb;
        // Get the current user id
        $user_id = get_current_user_id();
        $vouchers = $wpdb->get_results("SELECT * FROM `".$wpdb->prefix."voucher_codes` WHERE `user_id`=".$user_id.' ORDER BY `voucher_id` DESC');
        // Check the voucher codes are available or not
        if((isset($vouchers)) && (is_array($vouchers)) && (count($vouchers))) {
            // loop through the codes
            foreach($vouchers as $k => $v) {
                // get the order id
                $order_id = $v->order_id;
                // Fetch the order details
                if($order_id <> '') { // If the order id is not blank
                    $order = wc_get_order($order_id);                    
                    if((isset($order)) && (is_object($order))) { // If the order is valid
                        $order_status = $order->get_status();
                        $vouchers[$k]->order_status = $order_status;
                    }
                }
            }
        }
        $data['vouchers'] = $vouchers;

        // render the template
        $this->Template->render('vouchers', $data);
    }

    /**
     * this function creates the shortcodes for order related ui
     * @param void takes no parameter
     * @return void returns nothing
     */
    public function shortcodeGenerate() {
        // Short code for showing all vouchers for an user, ordered DESC
        add_shortcode('vouchers', array($this, 'vouchers'));
    }

    /**
     * this function initiates the hooks for functions related to ORDER
     * @param void takes no parameter
     * @return void returns nothing
     */
    public function initiateHook() {

    }
}