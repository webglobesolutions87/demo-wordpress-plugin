<?php
namespace GLF\Admin;

// Load the Template class
use GLF\Templates\Template;
// Load the PHPMAILER class
// use PHPMailer\PHPMailer\PHPMailer;

// No direct access
if (!defined('WPINC')) die;

class Admin {
    // Load the template class
    var $Template;

    public function __construct() {        
        // Initiate all wordpress hooks for user profile
        $this->initiateHook();
        $this->Template = new Template();
    }
    /**
     * Hook callback function for Creating Admin Menu Item
     * @param void takes no parameter
     * @return void returns nothing
     */
    public function makeAdminMenuHook() {
        // add_options_page( 'Golfero SMTP Settings', 'Golfero', 'manage_options', 'glofero-smtp', array($this, 'smtpConfiguration') );
        add_menu_page('Golfero Mail Content', 'Golfero', 'manage_options', 'glofero-mail-content', array($this, 'mailContent'));
        add_action('admin_init', array($this, 'settingInit') );
    }

    /**
     * page to update the mail content when user adds a new post and admin publishes it
     * @param void takes no parameter
     * @return void returns nothing
     */
    public function mailContent() {
        $data = array();
        $data['title'] = 'Email Contents';
        
        $lang['pending_posts_title']['en'] = 'Please enter the mail content for "Pending" posts';
        $lang['pending_posts_title']['cs'] = 'Zadejte obsah e-mailu pro příspěvky čekající na vyřízení';

        $lang['published_posts_title']['en'] = 'Please enter the mail content for "Published" posts';
        $lang['published_posts_title']['cs'] = 'Zadejte obsah e-mailu pro publikované příspěvky';

        $lang['general_instruction_about_language']['en'] = 'You can change your language from admin bar & put the content.';
        $lang['general_instruction_about_language']['cs'] = 'Můžete změnit svůj jazyk z administrátorské lišty a vložit obsah.';

        $data['lang'] = $lang;

        // render the template view file
        $this->Template->render('admin/email-template', $data);
    }

    /**
     * Initialize setting section
     * @param void takes no parameter
     * @return void returns nothing
     */
    public function settingInit() {
        add_settings_section(
            'glofero-settings-group', // id of the section
            'My Settings', // title to be displayed
            '', // callback function to be called when opening section
            'glofero-smtp' // page on which to display the section, this should be the same as the slug used in add_submenu_page()
        );

        // register_setting('glofero-settings-group', 'golfero_enable_smtp');
        // register_setting('glofero-settings-group', 'golfero_smtp_host');
        // register_setting('glofero-settings-group', 'golfero_smtp_port');
        // register_setting('glofero-settings-group', 'golfero_smtp_secure');
        // register_setting('glofero-settings-group', 'golfero_smtp_debug');
        // register_setting('glofero-settings-group', 'golfero_smtp_username');
        // register_setting('glofero-settings-group', 'golfero_smtp_password');
        // register_setting('glofero-settings-group', 'golfero_smtp_from_email');
        // register_setting('glofero-settings-group', 'golfero_smtp_from_name');
        if(ICL_LANGUAGE_CODE == 'en') {
            register_setting('glofero-settings-group', 'pending_posts_en');
            register_setting('glofero-settings-group', 'published_posts_en');
        } else {
            register_setting('glofero-settings-group', 'pending_posts_cs');        
            register_setting('glofero-settings-group', 'published_posts_cs');
        }
    }

    /**
     * page for SMTP configuration option
     * @param void takes no parameter
     * @return void returns nothing
     */
    public function smtpConfiguration() {
        // Data to be passed to the HTML template view file
        $data = array();
        $data['title'] = "PHPMAILER SMTP CONFIGURATION DATA";

        // render the HTML template for this page
        $this->Template->render('smtp-configuration', $data);
    }

    /**
     * Configures the PHPMAILER
     * @param Object The reference of the PHPMAILER
     * @return void returns nothing
     */
    public function configurePHPMailer($mail) {
        if ( ! is_object( $mail ) ) {
            $mail = (object) $mail;
        }
        // Check, if the SMTP is enabled or not
        if(esc_attr( get_option('golfero_enable_smtp') ) == '1') {
            $mail->IsSMTP();
            $mail->SMTPDebug = esc_attr( get_option('golfero_smtp_debug') );
            $mail->Mailer = "smtp";
            $mail->Host = esc_attr( get_option('golfero_smtp_host') );
            $mail->Port = esc_attr( get_option('golfero_smtp_port') ); // 8025, 587 and 25 can also be used. Use Port 465 for SSL.
            $mail->SMTPAuth = true;            
            $mail->SMTPSecure = esc_attr( get_option('golfero_smtp_secure') );
            $mail->Username = esc_attr( get_option('golfero_smtp_username') );
            $mail->Password = esc_attr( get_option('golfero_smtp_password') );

            $mail->From = esc_attr( get_option('golfero_smtp_from_email') );
            $mail->FromName = esc_attr( get_option('golfero_smtp_from_name') );
        }        
    }

    /**
     * send an email to the user who has added the post when post is published
     * @param int $ID - the post id
     * @param object $post - the post object
     * @return void returns nothing
     */
    public function postPublishNotification($ID, $post) {
        $author = $post->post_author; /* Post author ID. */
        $name = get_the_author_meta( 'display_name', $author );
        $email = get_the_author_meta( 'user_email', $author );
        $title = $post->post_title;
        $permalink = get_permalink( $ID );
        $edit = get_edit_post_link( $ID, '' );
        $to[] = sprintf( '%s <%s>', $name, $email );
        $subject = sprintf( 'Published: %s', $title );
        // $message = sprintf ('Congratulations, %s! Your article "%s" has been published.' . "\n\n", $name, $title );
        // $message .= sprintf( 'View: %s', $permalink );
        $message = get_option('published_posts_'.ICL_LANGUAGE_CODE);
        $message = str_replace('{{$title}}', $title, $message);
        $message = str_replace('{{$link}}', $permalink, $message);
        $headers[] = 'Content-Type: text/html; charset=UTF-8';
        wp_mail( $to, $subject, $message, $headers );
    }

    /**
     * Inititate the wordpress hooks associated with this profile
     * @param void takes nothing
     * @return void returns nothing
     */
    public function initiateHook() {
        // Hook for creating admin menu
        // Hook for admin page for email content. The content will be used when user adds a new post
        // After completion of it when the status is pending the email will be sent.
        // Also, when the post gets published another mail to be sent. content will be in both English & Czech
        // To switch languages admin needs to change the 
        add_action('admin_menu', array($this, 'makeAdminMenuHook'));
        // Hook for PHPMAILER configuration
        // add_action('phpmailer_init', array($this, 'configurePHPMailer'));        
        
        add_action( 'publish_post', array($this, 'postPublishNotification'), 10, 2 );
    }
}
?>