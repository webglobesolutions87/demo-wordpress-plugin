<?php
namespace GLF\Order;

// Load the Template class
use GLF\Templates\Template;

// No direct access
if (!defined('WPINC')) die;

class Order {
    // Load the template class
    var $Template;

    public function __construct() {
        // Add all short-codes for user profile
        $this->shortcodeGenerate();
        // Initiate all wordpress hooks for user profile
        $this->initiateHook();
        // Create the template object
        $this->Template = new Template();
    }

    /**
     * function for showing all orders by the current user
     * @param void takes no parameter
     * @return void returns nothing
     */
    public function orderHistory() {
        $data['title'] = 'Order History';

        $user_id = get_current_user_id();
        // Get all customer orders
        $customer_orders = wc_get_orders( array(
            'limit' => -1,
            'customer_id' => $user_id,
            'status' => array('on-hold','processing','completed'),
        ) );
        $data['orders'] = $customer_orders;

        // render the template
        $this->Template->render('order_history', $data);
    }

    /**
     * function for showing individual order details
     * @param void takes no parameter
     * @return void returns nothing
     */
    public function orderDetail() {
        // Create URL segments to get the order-id
        $uri_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $uri_segments = explode('/', trim($uri_path, '/'));

        $data['error'] = false;
        
        // Store the order id in a variable
        $order_id = $uri_segments[count($uri_segments) - 1];
        // retrieve the order details associated with the order id
        $order = wc_get_order($order_id);

        if($order->get_user_id() == get_current_user_id()) {
            $data['currency'] = $order->get_currency();
            $data['order_id'] = $order->get_id();
            $data['order_created_on'] = date('M j, Y @ H:i:s', strtotime($order->get_date_created()));
            $data['order_status'] = $order->get_status();
            $data['order_detail'] = $order->get_data();
            $data['order_items'] = $order->get_items();
            $data['order_total'] = $order->get_total();
            $data['customer_ip'] = $order->get_customer_ip_address();
            $data['payment_method'] = $order->get_payment_method_title();
        } else {
            $data['error'] = true;
        }

        

        // render the template
        $this->Template->render('order_detail', $data);
    }

    /**
     * this function creates the shortcodes for order related ui
     * @param void takes no parameter
     * @return void returns nothing
     */
    public function shortcodeGenerate() {
        // Short code for showing all orders, ordered by the current user
        add_shortcode('order_history', array($this, 'orderHistory'));
        // Shows the order detail of a particular order
        add_shortcode('order_details', array($this, 'orderDetail'));
    }

    /**
     * this function initiates the hooks for functions related to ORDER
     * @param void takes no parameter
     * @return void returns nothing
     */
    public function initiateHook() {

    }
}