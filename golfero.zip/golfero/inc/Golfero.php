<?php
    namespace GLF;

    // No direct access
    if (!defined('WPINC')) die;

    /**
     * The main plugin class.
     * Dependency injections - 
     * 1. $this->Template class GLF\Templates\Template
     */
    class Golfero extends \GLF\Foundations\MG_Golfero
    {
        // Initiate the object with parameters
        public function __construct() {
            parent::__construct();            
            $this->shortcodeGenerate();
            $this->hookGenerate();
        }
        /**
         * Start Output
         * @param void no parameter
         * @return void nothing returns
         */
        public function ob_start() {
		    ob_start();
        }
        
        /**
         * All functional job are done in this function regarding adding a new post by user
         * @param void no parameter
         * @return void returns nothing but outputs the desired template file with data
         */
        public function addNewPost() {
            
            // Prepare an empty array for passing the data to the view
            $data = array();
            // All post Formats like Audio, Video, Gallery etc
            $data['formats'] = $this->Post->postFormats();
            // All categories
            $data['categories'] = $this->Post->postCategories();
            // All Tags
            $data['tags'] = $this->Post->postTags();            
            // Active vouchers
            $data['vouchers'] = $this->Post->hasActiveProduct();

            $data['post_id'] = '';
            // If edit mode is on
            if((isset($_GET['post'])) && ($_GET['post'] <> '')) {
                $ID = $_GET['post'];
                $data['post_id'] = $_GET['post'];
                $post = get_post($ID);
                $post->format = get_post_format($ID);
                $post->category = get_the_category($ID);
                $tags = get_the_tags($ID);
                $tags_array = array();
                if((isset($tags)) && (is_array($tags)) && (count($tags))) {
                    foreach($tags as $k => $v) {
                        $tags_array[] = strtolower($v->name);
                    }
                }
                $post->tags = $tags_array;
                $post->featured_image = get_the_post_thumbnail_url($ID);
                $post->video_url = get_post_meta($ID, 'video_url', true);
                $post->audio_shortcode = get_post_meta($ID, 'audio_shortcode', true);
                $post->quote_author = get_post_meta($ID, 'quote_author', true);
                $post->external_link = get_post_meta($ID, 'external_link', true);
                $gallery_of_images = get_post_meta($ID, 'gallery_of_images');
                $gallery_image_urls = array();
                if((isset($gallery_of_images[0])) && (is_array($gallery_of_images[0])) && (count($gallery_of_images[0]))) {
                    $post->gallery_images = $gallery_of_images[0];

                    foreach($gallery_of_images[0] as $k => $v) {
                        $gallery_image_urls[] = wp_get_attachment_url($v);
                    }
                    $post->gallery_image_urls = $gallery_image_urls;
                }
                // var_dump($post); die();
                $data['edit_post'] = $post;
                $data['post_id'] = $ID;

                $voucher_id_used = get_post_meta($ID, '_voucher_id', true);
                $data['voucher_id_used'] = $voucher_id_used;
            }

            // Call the template file with data
            $this->Template->render('new-post', $data);
        }

        public function saveNewPost() {
            if(isset($_REQUEST['btnSubmit'])) {
                $title = $_REQUEST['title'];
                $format = $_REQUEST['format'];
                $category = $_REQUEST['category'];
                $tags = $_REQUEST['tags'];
                $content = $_REQUEST['content'];
                
                if(($_REQUEST['post_id'] == '') || ($_REQUEST['post_id'] == '0')) {
                    $postId = wp_insert_post([
                        'post_title' => $title,
                        'post_content' => $content,
                        'post_category' => [ '0' => $category ],
                        'tags_input' => $tags
                    ]);
                } else {
                    $postId = $_REQUEST['post_id'];
                    wp_update_post([
                        'ID' => $postId,
                        'post_title' => $title,
                        'post_content' => $content,
                        'post_category' => [ '0' => $category ],
                        'tags_input' => $tags
                    ]);
                }
                if($format <> 'st') {
                    set_post_format($postId, $format);
                }                
                if($_REQUEST['upload'] <> '') {
                    set_post_thumbnail( $postId, $_REQUEST['upload'] );
                }

                switch($format) {
                    case "video":
                        if(metadata_exists('post', $postId, 'video_url')) {
                            update_post_meta($postId, '_video_url', $_REQUEST['_video_url']);
                            update_post_meta($postId, 'video_url', $_REQUEST['video_url']);
                        } else {
                            add_post_meta($postId, '_video_url', $_REQUEST['_video_url']);
                            add_post_meta($postId, 'video_url', $_REQUEST['video_url']);
                        }                        
                    break;

                    case "audio":
                        if(metadata_exists('post', $postId, 'audio_shortcode')) {
                            update_post_meta($postId, '_audio_shortcode', $_REQUEST['_audio_shortcode']);
                            update_post_meta($postId, 'audio_shortcode', $_REQUEST['audio_shortcode']);
                        } else {
                            add_post_meta($postId, '_audio_shortcode', $_REQUEST['_audio_shortcode']);
                            add_post_meta($postId, 'audio_shortcode', $_REQUEST['audio_shortcode']);
                        }
                    break;

                    case "quote":
                        if(metadata_exists('post', $postId, 'quote_author')) {
                            update_post_meta($postId, '_quote_author', $_REQUEST['_quote_author']);
                            update_post_meta($postId, 'quote_author', $_REQUEST['quote_author']);
                        } else {
                            add_post_meta($postId, '_quote_author', $_REQUEST['_quote_author']);
                            add_post_meta($postId, 'quote_author', $_REQUEST['quote_author']);
                        }                        
                    break;

                    case "link":
                        if(metadata_exists('post', $postId, 'external_link')) {
                            update_post_meta($postId, '_external_link', $_REQUEST['_quote_author']);
                            update_post_meta($postId, 'external_link', $_REQUEST['quote_author']);
                        } else {
                            add_post_meta($postId, '_external_link', $_REQUEST['_external_link']);
                            add_post_meta($postId, 'external_link', $_REQUEST['external_link']);
                        }                        
                    break;

                    case "gallery":

                        if($_REQUEST['upload_gallery'] <> '') {
                            $upload_gallery_array = explode(',', trim($_REQUEST['upload_gallery'], ','));
                            $gallery_of_images = "a:".count($upload_gallery_array).":{";
                            $uploaded_gallery = false;

                            if((isset($upload_gallery_array)) && (is_array($upload_gallery_array)) && (count($upload_gallery_array))) {
                                foreach($upload_gallery_array as $k => $v) {
                                    $gallery_of_images .= "i:".$k.";s:".strlen($v).":\"".$v."\";";
                                    $uploaded_gallery = true;
                                }
                            }

                            $gallery_of_images .= '}';
                            $gallery_of_images = ($uploaded_gallery) ? $gallery_of_images : '' ;
                            
                            if(metadata_exists('post', $postId, '_gallery_of_images')) {
                                update_post_meta($postId, '_gallery_of_images', $_REQUEST['_gallery_of_images']);
                            } else {
                                add_post_meta($postId, '_gallery_of_images', $_REQUEST['_gallery_of_images']);
                            }

                            global $wpdb;
                            if(metadata_exists('post', $postId, 'gallery_of_images')) {
                                $wpdb->update($wpdb->prefix . 'postmeta', array('meta_value'=>$gallery_of_images), array('post_id'=>$postId, 'meta_key'=>'gallery_of_images'));                            
                            } else {
                                $wpdb->insert($wpdb->prefix . 'postmeta', array(
                                    'post_id' => $postId,
                                    'meta_key' => 'gallery_of_images',
                                    'meta_value' => $gallery_of_images
                                ));
                            }
                        }
                    break;
                }
                               
                $flash = [
                    'class' => 'success',
                    'icon' => '<i class="fa fa-check" aria-hidden="true"></i>',
                    'message' => ''
                ];
                $_SESSION['flash'] = $flash;

                // check if the customer has any kind of paid & active product or not
                // $purchased_products = $this->Post->hasActiveProduct();
                if((isset($_POST['_voucher'])) && ($_POST['_voucher'] <> '')) {
                    // $_no_of_posts = ((isset($_POST['_no_of_posts'])) && ($_POST['_no_of_posts'] > 0)) ? ($_POST['_no_of_posts']-1) : 0;
                    // wc_update_order_item_meta($_POST['_voucher'], '_no_of_posts', $_no_of_posts);                    
                    global $wpdb;
                    $voucher_id = $_POST['_voucher'];                    
                    if($_POST['_voucher'] == '0') { // If the voucher code is entered manually
                        // The voucher id is stored into the filed "_hidden_voucher"
                        $voucher_id = $_POST['_hidden_voucher'];
                    }
                    
                    // Find the voucher detail from the database table
                    $selected_voucher = $wpdb->get_results("SELECT * FROM `".$wpdb->prefix."voucher_codes` WHERE `voucher_id`=".$voucher_id);
                    
                    if(($selected_voucher[0]->available_post > 0) && (strtotime($selected_voucher[0]->validity) > strtotime(date('Y-m-d')))) {
                        // Reduce the available post by one
                        $available_post = ($selected_voucher[0]->available_post - 1);
                        if($available_post >= 0) {
                            // Prepare the post data
                            $data = [ 'available_post' => $available_post ];
                            // Ser the condition
                            $where = [ 'voucher_id' => $voucher_id ];
                            // Run the wordpress built-in update query
                            $wpdb->update( $wpdb->prefix . 'voucher_codes', $data, $where);
                            
                            // We also need to link the post with the associated voucher
                            // For convinience we added meta information, Voucher id (_voucher_id)
                            update_post_meta($postId, '_voucher_id', $voucher_id);

                            if(strtolower(get_post_status($postId)) <> 'publish') {
                                wp_update_post([
                                    'ID' => $postId,
                                    'post_status' => 'pending'
                                ]);
                            }
                        }
                                                
                    }
                    
                }

                if( !((isset($_GET['post'])) && ($_GET['post'] <> '')) ){
                    $ID = $postId;
                    $post = get_post($ID);

                    $author = $post->post_author; /* Post author ID. */
                    $name = get_the_author_meta( 'display_name', $author );
                    $email = get_the_author_meta( 'user_email', $author );
                    $title = $post->post_title;
                    $permalink = get_permalink( $ID );
                    $edit = get_edit_post_link( $ID, '' );
                    $to[] = sprintf( '%s <%s>', $name, $email );
                    $subject = sprintf( 'Success: " %s " - has been posted', $title );
                    // $message = sprintf ('Congratulations, %s! Your article "%s" has been published.' . "\n\n", $name, $title );
                    // $message .= sprintf( 'View: %s', $permalink );
                    $message = get_option('pending_posts_'.ICL_LANGUAGE_CODE);
                    $message = str_replace('{{$title}}', $title, $message);
                    $message = str_replace('{{$link}}', $permalink, $message);
                    $headers[] = 'Content-Type: text/html; charset=UTF-8';
                    wp_mail( $to, $subject, $message, $headers );
                }

                
                echo "<script>";
                echo "window.location.href = '".get_site_url().'/'.ICL_LANGUAGE_CODE."/dashboard/?uploaded=1';";
                echo "</script>";
                exit();
            }
        }

        /**
         * This function is custom hook validates when customer adds some product to the cart
         * We need to prevent a product to be added multiple time so that the no of items should always be 1.         * 
         * @param void takes no parameter
         * @return void returns nothing
         */
        public function addToCartValidation($is_valid, $product_id) {
            // Loop throuogh the cart items
            foreach(WC()->cart->get_cart() as $cart_item_key => $values) {
                // Compare the product id with the product id in the cart
                if ($values['data']->id == $product_id) {
                    // Fetch the product url
                    $product_url = get_permalink( $product_id );

                    // If product is already in the cart then simply redirect to the product page
                    // The product won't be added to the cart again
                    echo "<script>";
                    echo "window.location.href='".$product_url."';";
                    echo "</script>";
                    exit();
                    return false;
                }
            }
            return $is_valid;
        }

        /**
         * Creates the tables while activating the plugin
         * @param void takes no parameter
         * @return void returns nothing
         */
        public function createDB() {
            /**
             * CREATE TABLE `golferonews_test`.`wp_voucher_codes` ( `voucher_id` INT(11) NOT NULL AUTO_INCREMENT , 
             * `voucher_code` VARCHAR(255) NOT NULL , `user_id` INT(11) NOT NULL , `validity` VARCHAR NOT NULL , 
             * `no_of_posts` INT(11) NOT NULL , PRIMARY KEY (`voucher_id`)) ENGINE = MyISAM;
             * 
             * ALTER TABLE `wp_voucher_codes` ADD `available_post` INT(11) NOT NULL AFTER `no_of_posts`;
             */
        }

        /**
         * This function creates a metabox in the admin panel edit "Post" page, it shows the voucher used
         * and the payment status for that voucher
         * @param object the post object
         * @return void returns nothing
         */
        public function voucherInfoMetaBoxforPostsAdmin($post) {
            add_meta_box( 'voucher-details-for-posts-admin', __( 'Voucher Details', 'textdomain' ), array($this, 'voucherMetaBoxCallback'), 'post', 'side');            
        }

        public function voucherMetaBoxCallback($post) {
            // Initiate the global $wpdb variable
            global $wpdb;
            // Initialize the default data array which is to be sent to the template file
            $data = ['voucher' => '', 'order_status' => '', 'order_id' => ''];
            // Fetch the voucher id stored into the post-meta _voucher_id
            $voucher_id = get_post_meta($post->ID, '_voucher_id', true);
            // Find details about the voucher
            $voucher = $wpdb->get_results("SELECT * FROM `".$wpdb->prefix."voucher_codes` WHERE `voucher_id`=".$voucher_id);
            // If the voucher code is found
            if((isset($voucher)) && (is_array($voucher)) && (count($voucher) == 1)) {
                // Store the voucher object to pass to the view / template file
                $data['voucher'] = $voucher[0];
            }
            // Get the order status
            if((isset($voucher[0])) && ($voucher[0]->order_id <> '')) { // If the voucher id is 
                // Fetch the order details using woocommerce function
                $order = wc_get_order( $voucher[0]->order_id );
                // store the "order_status" into the data object
                $data['order_status'] = $order->get_status();
                $data['order_id'] = $voucher[0]->order_id;
            }
            
            // Call the template file with data
            $this->Template->render('admin_voucher_meta', $data);
        }

        public function start_session() {
            if(!session_id()) {
                session_start();
            }
        }

        /**
         * Generates all shortcodes required for this plugin
         * @param void takes no parameter
         * @return void returns nothing, just hook the short codes
         */
        public function shortcodeGenerate() {
            // For displaying the add new post
            add_shortcode('add_new_post', array($this, 'addNewPost'));            
        }
        /**
         * This function allows to subscriber role user upload files
         * @param void takes no parameter
         * @return void returns nothing, just hook the short codes
         */
         public function allow_subscriber_uploads() {

            $contributor = get_role('subscriber');
            $contributor->add_cap('upload_files');

        }
        public function hookGenerate() {
            add_action('init', array($this, 'start_session'), 1);
            add_action('init', array($this, 'saveNewPost'), 10);
            // validate the cart before the product gets added to the cart
            add_action('woocommerce_add_to_cart_validation', array($this, 'addToCartValidation'), 10, 2 );
            register_activation_hook( __FILE__, array($this, 'createDB') );
            add_action( 'add_meta_boxes', array($this, 'voucherInfoMetaBoxforPostsAdmin') );
            // Allow the subscriber to upload files to the media library
            add_action('admin_init',  array($this,'allow_subscriber_uploads'));
        }
    }
?>