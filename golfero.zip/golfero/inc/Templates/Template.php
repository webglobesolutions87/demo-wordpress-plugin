<?php
namespace GLF\Templates;

// No direct access
if (!defined('WPINC')) die;

class Template {
    public function __construct() {

    }

    public function render($template, $data = '') {
        if((isset($data)) && (is_array($data)) && (count($data))) {
            extract($data);
        }        
        include GLF_TEMPLATES_DIR.$template.'.php';
    }
}
?>