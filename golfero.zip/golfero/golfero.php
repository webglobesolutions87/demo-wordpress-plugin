<?php
    // TODO: We need to enable the users to add custom post from the front end.
    // Conditions should apply - 
    // 1. User is not logged in, will be redirected to the Login page
    // 2. Logged in but not subscribed then redirect to the product page
    // 3. Logged in & subscribed but all options to post are used, show a message & encourage to updgrade
    // - If all of the above conditions are negetive, we let the user to post.
    /**
     * Plugin Name: Golfero
     * Description: Custom functions to support the current theme
     * Version: 1.0.0
     * Author: Mejora Infotech Pvt. Ltd.
     * Author URI: https://www.mejorainfotech.com/
     */

    if (!defined('WPINC')) die; // restrict direct accessing

    if (version_compare(PHP_VERSION, '5.4', '<')) { // Plug in requires the server to have at least PHP v5.4 to be installed.
        wp_die(sprintf('Frontend Publishing Pro plugin requires PHP 5.4 or higher. You’re still on %s. Please upgrade.', PHP_VERSION));
    }

    // All constants required for this development is included here
    require_once 'constants.php';
    // Enable our classes to be autoloaded
    require_once 'autoloader.php';
    // All global functions are declared here
    require_once 'global-functions.php';

    // Function to load the instance of our main plugin
    function glf_run() {
        $plugin = new GLF\Golfero();
    }
    // Run the function
    glf_run();
?>