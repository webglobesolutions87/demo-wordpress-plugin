<?php
// No direct access
if (!defined('WPINC')) die;

// Define autoload function
function glf_autoload_function( $classname ) {
    if( strpos( $classname, 'GLF' ) === false ) {
        return;
    }

    $class = str_replace( '\\', DIRECTORY_SEPARATOR, $classname );
    $class = str_replace( 'GLF', 'inc', $class );

    // create the actual filepath
    $filePath = dirname(__FILE__) . DIRECTORY_SEPARATOR . $class . '.php';

    // check if the file exists
    if(file_exists($filePath))
    {
        // require once on the file
        require_once $filePath;
    }
}
// Auto load the files by calling the above function as parameter
// In php, we have "spl_autoload_register" which does the remaining jobs
spl_autoload_register('glf_autoload_function');