<?php
namespace GLF;

// Prevent direct accessing
if (!defined('WPINC')) die;

/**
 * wordpress has it's own which is wp_redirect, which sometimes shows error "header already sent"
 * So, we are keeping the function in case wp_redirect fails
 * @param string the url to redirect
 * @return void retuns nothing
 */
function glf_redirect($url) {
    // This function redirects using javascript on the fly
    echo "<script>";
    echo "window.location.href = '".$url."';";
    echo "</script>";
}
